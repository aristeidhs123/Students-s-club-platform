import express from "express";

import {
    getCompletedEventsForReview,
    createEventReview,
    getPublicEventReviews,
    getAllPublicEventReviews
} from "../controllers/eventReviewController.js";

const router = express.Router();

router.get("/completed/:userId", getCompletedEventsForReview);

router.get("/public", getAllPublicEventReviews);

router.get("/public/:eventId", getPublicEventReviews);

router.post("/:eventId", createEventReview);

export default router;