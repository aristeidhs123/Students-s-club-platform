import db from "../config/db.js";

export async function createuser(name, lastname, email, password) {
    const [result] = await db.query(
        "INSERT INTO user (name, lastname, email, password, role) VALUES (?, ?, ?, ?, 'user')",
        [name, lastname, email, password]
    );
    return result;
}

export async function searchuser(email) {
    const [rows] = await db.query("SELECT * FROM user WHERE email = ?", [email]);
    return rows[0] || null;
}

export async function editprofile(id, userimg, bio, interests) {
    const [result] = await db.query(
        "UPDATE user SET profil_img = ?, user_bio = ?, user_interests = ? WHERE user_id = ?",
        [userimg, bio, interests, id]
    );
    return result;
}

export async function turntomanager(id) {
    const [result] = await db.query("UPDATE user SET role = 'manager' WHERE user_id = ?", [id]);
    return result;
}

export async function showprofile(id) {
    const [rows] = await db.query("SELECT * FROM user WHERE user_id = ?", [id]);
    return rows[0] || null;
}

export async function returnusrole(id) {
    const userId = typeof id === "object" ? (id.user_id || id.userid || id.id || id.managerid) : id;
    const [rows] = await db.query("SELECT role FROM user WHERE user_id = ?", [userId]);
    return rows[0]?.role || null;
}

export async function club(title, descr, managerid) {
    const [result] = await db.query(
        "INSERT INTO club (title, description, manager_id, status) VALUES (?, ?, ?, 'pending')",
        [title, descr, managerid]
    );
    return result;
}

export async function rejectclub(clubid) {
    const id = typeof clubid === "object" ? (clubid.club_id || clubid.clubid || clubid.id) : clubid;
    const [result] = await db.query("UPDATE club SET status = 'deleted' WHERE club_id = ?", [id]);
    return result;
}

export async function acceptclub(clubid) {
    const id = typeof clubid === "object" ? (clubid.club_id || clubid.clubid || clubid.id) : clubid;
    const [result] = await db.query("UPDATE club SET status = 'approved' WHERE club_id = ?", [id]);
    return result;
}

export async function show_pendingClubs() {
    const [rows] = await db.query("SELECT * FROM club WHERE status = 'pending' ORDER BY creationdate DESC");
    return rows;
}

export async function showclubs() {
    const [rows] = await db.query("SELECT * FROM club WHERE status = 'approved' ORDER BY creationdate DESC");
    return rows;
}

export async function searchclubs(clubid) {
    const [rows] = await db.query("SELECT * FROM club WHERE club_id = ?", [clubid]);
    return rows[0] || null;
}

export async function searchmanagerclubs(managerid) {
    const id = typeof managerid === "object" ? (managerid.managerid || managerid.user_id || managerid.userid || managerid.id) : managerid;
    const [rows] = await db.query("SELECT * FROM club WHERE manager_id = ?", [id]);
    return rows;
}

export async function newmembership(iduser, idclub) {
    const [result] = await db.query(
        "INSERT INTO membership (userid, clubid, membership_role, membership_status) VALUES (?, ?, 'user', 'pending')",
        [iduser, idclub]
    );
    return result;
}

export async function show_pendingMemberships() {
    const [rows] = await db.query(
        `SELECT m.*, u.name, u.lastname, u.email, c.title AS club_title
         FROM membership m
         JOIN user u ON u.user_id = m.userid
         JOIN club c ON c.club_id = m.clubid
         WHERE m.membership_status = 'pending'
         ORDER BY m.membershipdate DESC`
    );
    return rows;
}

export async function show_approvedMemberships() {
    const [rows] = await db.query(
        `SELECT m.*, u.name, u.lastname, u.email, c.title AS club_title
         FROM membership m
         JOIN user u ON u.user_id = m.userid
         JOIN club c ON c.club_id = m.clubid
         WHERE m.membership_status = 'approved'
         ORDER BY m.membershipdate DESC`
    );
    return rows;
}

export async function show_rejectMemberships() {
    const [rows] = await db.query("SELECT * FROM membership WHERE membership_status = 'rejected'");
    return rows;
}

export async function makemanagermember(idmanag) {
    const [result] = await db.query("UPDATE membership SET membership_role = 'manager' WHERE membership_id = ?", [idmanag]);
    return result;
}

export async function apprmember(memberid) {
    const id = typeof memberid === "object" ? (memberid.membership_id || memberid.memberid || memberid.id) : memberid;
    const [result] = await db.query("UPDATE membership SET membership_status = 'approved' WHERE membership_id = ?", [id]);
    return result;
}

export async function rejmember(memberid) {
    const id = typeof memberid === "object" ? (memberid.membership_id || memberid.memberid || memberid.id) : memberid;
    const [result] = await db.query("UPDATE membership SET membership_status = 'rejected' WHERE membership_id = ?", [id]);
    return result;
}

export async function searchmemberships(userid) {
    if (userid) {
        const id = typeof userid === "object" ? (userid.userid || userid.user_id || userid.id) : userid;
        const [rows] = await db.query(
            "SELECT * FROM membership WHERE userid = ? AND membership_status = 'approved'",
            [id]
        );
        return rows;
    }

    const [rows] = await db.query("SELECT * FROM membership WHERE membership_status = 'approved'");
    return rows;
}

export async function newevent(clubid, title, description, role, seats, location, gplatos, gmikos, starttime, endtime) {
    const [result] = await db.query(
        `INSERT INTO event
        (ev_clubid, ev_title, ev_description, ev_role, ev_seats, ev_location, ev_gplatos, ev_gmikos, ev_starttime, ev_endtime)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [clubid, title, description, role, seats, location, gplatos, gmikos, starttime, endtime]
    );
    return result;
}

export async function showallevents() {
    const [rows] = await db.query(
        `SELECT e.*, c.title AS club_title
         FROM event e
         LEFT JOIN club c ON c.club_id = e.ev_clubid
         ORDER BY e.ev_starttime DESC`
    );
    return rows;
}

export async function showpublicevents() {
    const [rows] = await db.query(
        `SELECT e.*, c.title AS club_title
         FROM event e
         LEFT JOIN club c ON c.club_id = e.ev_clubid
         WHERE e.ev_role = 'public'
         ORDER BY e.ev_starttime DESC`
    );
    return rows;
}

export async function showprivateevents() {
    const [rows] = await db.query(
        `SELECT e.*, c.title AS club_title
         FROM event e
         LEFT JOIN club c ON c.club_id = e.ev_clubid
         WHERE e.ev_role = 'private'
         ORDER BY e.ev_starttime DESC`
    );
    return rows;
}

export async function showclubevents(clubids) {
    if (!Array.isArray(clubids)) return [];
    const ids = clubids.map(x => x.clubid || x.club_id || x).filter(Boolean);
    if (ids.length === 0) return [];
    const [rows] = await db.query("SELECT * FROM event WHERE ev_clubid IN (?)", [ids]);
    return rows;
}

export async function checkeventsloc(location, starttime, endtime) {
    const [rows] = await db.query(
        `SELECT event_id FROM event
         WHERE ev_location = ?
         AND NOT (ev_endtime <= ? OR ev_starttime >= ?)
         LIMIT 1`,
        [location, starttime, endtime]
    );
    return rows.length > 0;
}

export async function pastevents(useridev) {
    if (useridev) {
        const id = typeof useridev === "object" ? (useridev.userid || useridev.user_id || useridev.id) : useridev;
    const [pastev] = await db.query('SELECT ev.* FROM event e JOIN reservation res ON e.event_id = res.res_evid WHERE res.res_userid = ? AND e.ev_endtime < NOW() AND res.res_status = "approved" AND res.res_apprearedatevent = TRUE ORDER BY e.ev_endtime DESC', [useridev])
    return pastev
    }
}

export async function reservationevent(eventid, userid) {
    const [result] = await db.query(
        "INSERT INTO reservation (res_evid, res_userid, res_status, res_apprearedatevent) VALUES (?, ?, 'pending', false)",
        [eventid, userid]
    );
    return result;
}

export async function showpendingreservation() {
    const [rows] = await db.query(
        `SELECT r.*, e.ev_title, u.name, u.lastname
         FROM reservation r
         JOIN event e ON e.event_id = r.res_evid
         JOIN user u ON u.user_id = r.res_userid
         WHERE r.res_status = 'pending'
         ORDER BY r.reservationdate DESC`
    );
    return rows;
}

export async function acceptreservation(resid) {
    const id = typeof resid === "object" ? (resid.res_id || resid.resid || resid.id) : resid;
    const [result] = await db.query("UPDATE reservation SET res_status = 'approved' WHERE res_id = ?", [id]);
    return result;
}

export async function rejectreservation(resid) {
    const id = typeof resid === "object" ? (resid.res_id || resid.resid || resid.id) : resid;
    const [result] = await db.query("UPDATE reservation SET res_status = 'rejected' WHERE res_id = ?", [id]);
    return result;
}

export async function appearedatevent(resid) {
    const [result] = await db.query("UPDATE reservation SET res_apprearedatevent = TRUE WHERE res_id = ?", [resid]);
    return result;
}

export async function newprannouncements(idclub, iduser, title, descr) {
    const [result] = await db.query(
        "INSERT INTO announcements (ann_clubid, ann_userid, ann_descr, ann_title) VALUES (?, ?, ?, ?)",
        [idclub, iduser, descr, title]
    );
    return result;
}

export async function newpublannouncements(managerid, description, title) {
    const [clubs] = await db.query(
        "SELECT club_id FROM club WHERE manager_id = ? AND status = 'approved' ORDER BY club_id LIMIT 1",
        [managerid]
    );

    const clubId = clubs[0]?.club_id || 1;

    const [result] = await db.query(
        "INSERT INTO announcements (ann_clubid, ann_userid, ann_descr, ann_title) VALUES (?, ?, ?, ?)",
        [clubId, managerid, description, title]
    );

    return result;
}

export async function showpublicannnouncements() {
    const [rows] = await db.query(
        `SELECT
            a.announc_id,
            a.ann_clubid,
            a.ann_userid,
            a.ann_title,
            a.ann_descr,
            a.ann_date,
            c.title AS club_title,
            u.name AS author_name,
            u.lastname AS author_lastname
         FROM announcements a
         LEFT JOIN club c 
            ON c.club_id = a.ann_clubid
         LEFT JOIN user u 
            ON u.user_id = a.ann_userid
         ORDER BY a.ann_date DESC`
    );

    return rows;
}

export async function showprclubannouncements(clubid) {
    const [rows] = await db.query(
        `SELECT
            a.*,
            c.title AS club_title
         FROM announcements a
         LEFT JOIN club c ON c.club_id = a.ann_clubid
         WHERE a.ann_clubid = ?
         ORDER BY a.ann_date DESC`,
        [clubid]
    );
    return rows;
}

export async function newreviewev(reventid, ruserid, review, revdescription) {
    const [result] = await db.query(
        "INSERT INTO review_EVENT (r_eventid, r_userid, r_review, r_descr) VALUES (?, ?, ?, ?)",
        [reventid, ruserid, review, revdescription]
    );
    return result;
}

export async function newstats(statsuserid, statstype, stats) {
    const [result] = await db.query(
        "INSERT INTO statistics (stats_userid, statstype, stats) VALUES (?, ?, ?)",
        [statsuserid, statstype, stats]
    );
    return result;
}
