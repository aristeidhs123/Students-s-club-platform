
import { EventsAPI, getCurrentUser } from "../connection_f_b/api.js";


document.addEventListener("DOMContentLoaded", async () => {
    const inputs = document.querySelectorAll("input, textarea");
    const button = document.querySelector("button.primary-btn");
    const clublist = document.getElementById("managerclublist");
    if (!button) return;
    const manager = getCurrentUser()
    if(manager && clublist){
        try{
            const club = await EventsAPI.getManagerClubs();
            console.log(club)
            clublist.innerHTML= '<option value=""> Επέλεξε έναν σύλλογο: </option> '
            const clubarr = Array.isArray(club) ? club:club.data
            club.forEach(i => {
                const eachclub = document.createElement("option");
                eachclub.value = i.club_id;
                eachclub.textContent = i.title;
                clublist.appendChild(eachclub)
           
            })
        }
        catch(error){
            console.error(error);
            clublist.innerHTML='<option value=""> Error </option>'
        }
    }

     
    button.addEventListener("click", async () => {
        const title = inputs[0]?.value?.trim();
        const description = inputs[1]?.value?.trim();
        const location = inputs[2]?.value?.trim();
        const seats = inputs[3]?.value || 0;
        const starttime = inputs[4]?.value;
        const clubchoiceid = clublist?.value;

        if (!title || !description || !location || !starttime || !clubchoiceid) {
            return alert("Συμπλήρωσε τίτλο, περιγραφή, τοποθεσία και ημερομηνία.");
        }

        const start = starttime.replace("T", " ") + ":00";
        const endDate = new Date(starttime);
        endDate.setHours(endDate.getHours() + 2);
        const end = endDate.toISOString().slice(0, 19).replace("T", " ");

        try {
            await EventsAPI.create({
                evclubid: parseInt(clubchoiceid),
                title,
                description,
                role: "public",
                seats: parseInt(seats),
                location,
                gplatos: 38.246242,
                gmikos: 21.735084,
                starttime: start,
                endtime: end
            });
            alert("Η εκδήλωση στάλθηκε στο backend.");
            window.location.href = "events.html";
        } catch (error) {
            alert("Σφάλμα δημιουργίας εκδήλωσης.");
        }
    });

});