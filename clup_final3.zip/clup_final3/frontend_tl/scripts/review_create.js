import {
  EventsAPI,
  ReviewsAPI,
  getCurrentUser,
  getCurrentUserId
} from "../connection_f_b/api.js";

const select = document.getElementById("event-select");
const ratingInput = document.getElementById("rating");
const descriptionInput = document.getElementById("description");
const submitBtn = document.getElementById("submit-btn");
const messageEl = document.getElementById("review-message");
const infoEl = document.getElementById("review-info");

document.addEventListener("DOMContentLoaded", loadCompletedEvents);
submitBtn.addEventListener("click", submitReview);

async function loadCompletedEvents() {
  const user = getCurrentUser();

  if (!user) {
    showMessage("Πρέπει να συνδεθείς για να κάνεις αξιολόγηση.", false);
    submitBtn.disabled = true;

    setTimeout(() => {
      window.location.href = "login.html";
    }, 900);

    return;
  }

  try {
    select.innerHTML = `<option value="">Φόρτωση εκδηλώσεων...</option>`;

    const userId = getCurrentUserId();
    const result = await EventsAPI.getCompletedForReview(userId);
    const events = result.events || result.data || [];

    select.innerHTML = "";

    if (!events.length) {
      select.innerHTML = `
        <option value="">
          Δεν υπάρχουν διαθέσιμες ολοκληρωμένες εκδηλώσεις για αξιολόγηση
        </option>
      `;

      submitBtn.disabled = true;
      showMessage("Δεν υπάρχει εκδήλωση που μπορείς να αξιολογήσεις.", false);

      return;
    }

    events.forEach((event) => {
      const option = document.createElement("option");

      option.value = event.event_id;
      option.textContent = event.ev_title || event.title || "Εκδήλωση";

      select.appendChild(option);
    });

    submitBtn.disabled = false;

    if (infoEl) {
      infoEl.textContent =
        "Επίλεξε μία ολοκληρωμένη εκδήλωση στην οποία έχεις συμμετάσχει.";
    }

  } catch (error) {
    select.innerHTML = `
      <option value="">Σφάλμα φόρτωσης εκδηλώσεων</option>
    `;

    submitBtn.disabled = true;
    showMessage(error.message || "Δεν φορτώθηκαν οι εκδηλώσεις.", false);
  }
}

async function submitReview() {
  const eventId = select.value;
  const rating = Number(ratingInput.value);
  const description = descriptionInput.value.trim();
  const userId = getCurrentUserId();

  if (!eventId) {
    showMessage("Επίλεξε εκδήλωση.", false);
    return;
  }

  if (!rating || rating < 1 || rating > 5) {
    showMessage("Η βαθμολογία πρέπει να είναι από 1 έως 5.", false);
    return;
  }

  if (!description) {
    showMessage("Γράψε ένα σύντομο σχόλιο για την αξιολόγηση.", false);
    return;
  }

  try {
    submitBtn.disabled = true;
    showMessage("Αποθήκευση αξιολόγησης...", true);

    await ReviewsAPI.create(eventId, {
      user_id: userId,
      rating: rating,
      description: description
    });

    showMessage("Η αξιολόγηση αποθηκεύτηκε επιτυχώς.", true);

    setTimeout(() => {
      window.location.href = "reviews.html";
    }, 800);

  } catch (error) {
    showMessage(error.message || "Δεν ήταν δυνατή η αποθήκευση αξιολόγησης.", false);
    submitBtn.disabled = false;
  }
}

function showMessage(text, success) {
  messageEl.textContent = text;
  messageEl.className = success
    ? "auth-message success"
    : "auth-message error";
}