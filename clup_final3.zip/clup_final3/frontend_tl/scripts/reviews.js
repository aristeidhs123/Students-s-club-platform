import { ReviewsAPI } from "../connection_f_b/api.js";

document.addEventListener("DOMContentLoaded", loadReviews);

async function loadReviews() {
    const list = document.getElementById("reviews-list");

    if (!list) return;

    list.innerHTML = "<p>Φόρτωση αξιολογήσεων...</p>";

    try {
        const result = await ReviewsAPI.getAll();
        const reviews = result.reviews || result.data || [];

        list.innerHTML = "";

        if (!reviews.length) {
            list.innerHTML = "<p>Δεν υπάρχουν ακόμα αξιολογήσεις.</p>";
            return;
        }

        reviews.forEach((review, index) => {
            const item = document.createElement("div");
            item.className = getCardClass(index);

            item.innerHTML = `
                <div class="card-top"></div>
                <div class="card-content">
                    <h3>${escapeHtml(review.ev_title || "Εκδήλωση")}</h3>
                    <p><strong>Βαθμολογία:</strong> ${renderStars(review.r_review)} (${review.r_review}/5)</p>
                    <p>${escapeHtml(review.r_descr || "Δεν υπάρχει σχόλιο.")}</p>
                    <p><strong>Χρήστης:</strong> ${escapeHtml((review.name || "") + " " + (review.lastname || ""))}</p>
                </div>
            `;

            list.appendChild(item);
        });

    } catch (error) {
        console.error("Load reviews error:", error);
        list.innerHTML = "<p>Σφάλμα φόρτωσης αξιολογήσεων.</p>";
    }
}

function getCardClass(index) {
    const classes = ["card card-blue", "card card-purple", "card card-cyan"];
    return classes[index % classes.length];
}

function renderStars(value) {
    const rating = Number(value) || 0;
    const full = "★".repeat(Math.max(0, Math.min(5, rating)));
    const empty = "☆".repeat(Math.max(0, 5 - rating));

    return full + empty;
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}