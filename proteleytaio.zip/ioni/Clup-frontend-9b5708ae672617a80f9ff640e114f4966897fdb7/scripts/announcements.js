import { AnnouncementsAPI } from "../connection_f_b/api.js"; 
import { openModal, closeModal, thankYou } from './utils.js'; // ΔΙΟΡΘΩΣΗ: Σωστό path για τον ίδιο φάκελο

// 1. ΦΟΡΤΩΣΗ ΟΛΩΝ ΤΩΝ ΑΝΑΚΟΙΝΩΣΕΩΝ ΣΤΗ ΛΙΣΤΑ
async function loadAnnouncements() {
  const list = document.getElementById("announcements-list");
  if (!list) return; // Αν δεν είμαστε στη σελίδα των ανακοινώσεων, σταματάει εδώ

  try {
    const result = await AnnouncementsAPI.getAll();
    const announcements = result.data || [];

    list.innerHTML = "";

    // Αν το API είναι άδειο, αφήνουμε τα στατικά cards που έχεις στο HTML
    if (announcements.length === 0) {
      console.log("ℹ️ Το API δεν επέστρεψε ανακοινώσεις, εμφανίζονται τα δοκιμαστικά cards του HTML.");
      setupViewButtons(); // Ενεργοποιούμε τα κουμπιά και για τα στατικά cards
      return;
    }

    announcements.forEach(a => {
      const item = document.createElement("div");
      item.className = "card card-cyan"; // Χρησιμοποιούμε τις δικές σου κλάσεις για ομοιομορφία

      item.innerHTML = `
        <div class="card-top gradient-3"></div>
        <div class="card-content">
          <h3>${a.ann_title || a.anc_title}</h3>
          <p>${a.ann_descr || a.anc_body}</p>
          <p><strong>Club ID:</strong> ${a.ann_clubid || a.club_id || 'N/A'}</p>
          <p><strong>Visibility:</strong> ${a.ann_visibility || 'Public'}</p>
          <button data-id="${a.ann_id || a.id}" class="card-btn view-btn">View Announcement</button>
        </div>
      `;

      list.appendChild(item);
    });

    setupViewButtons();

  } catch (error) {
    console.error("💥 Σφάλμα φόρτωσης:", error);
    // Δεν χαλάμε τη σελίδα, απλά ενημερώνουμε την κονσόλα και αφήνουμε τα στατικά σου cards
    setupViewButtons();
  }
}

// Συνάρτηση για να ακούει το κλικ στα κουμπιά "View"
function setupViewButtons() {
  document.querySelectorAll(".card-btn, .view-btn").forEach(btn => {
    // Αποφεύγουμε διπλούς listeners
    if (btn.getAttribute('data-listener') === 'true') return;
    
    btn.addEventListener("click", (e) => {
      const id = e.target.getAttribute("data-id") || "1"; // default 1 για δοκιμή
      window.location.href = `announcement_details.html?id=${id}`; // Σωστή σελίδα ανακοινώσεων
    });
    btn.setAttribute('data-listener', 'true');
  });
}

// 2. ΔΙΑΧΕΙΡΙΣΗ SUBMIT ΤΗΣ ΦΟΡΜΑΣ (Δημιουργία Ανακοίνωσης)
function setupForm() {
  const annForm = document.getElementById('annForm');
  const roleSelect = document.getElementById("user_role");
  const adminFields = document.getElementById("admin_only_fields");

  if (!annForm) return;

  // Εφέ για την εμφάνιση των Admin πεδίων
  if (roleSelect && adminFields) {
    roleSelect.addEventListener("change", (e) => {
      if (e.target.value === "admin") {
        adminFields.style.visibility = "visible";
        adminFields.style.height = "auto";
        adminFields.style.overflow = "visible";
        adminFields.style.marginBottom = "12px";
      } else {
        adminFields.style.visibility = "hidden";
        adminFields.style.height = "0px";
        adminFields.style.overflow = "hidden";
        adminFields.style.marginBottom = "0px";
      }
    });
  }

  // Submit Φόρμας
  annForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const data = {
      user_role: document.getElementById("user_role").value,
      club_id: document.getElementById("ann_clubid").value,
      anc_title: document.getElementById("title").value,
      anc_body: document.getElementById("desc").value,
      visibility: document.getElementById("ann_visibility")?.value || "public"
    };

    try {
      console.log("🚀 Αποστολή ανακοίνωσης:", data);
      
      // Στέλνουμε τα δεδομένα στο API σου
      await AnnouncementsAPI.create(data);
      
      // Κλείνουμε το modal χρησιμοποιώντας τη δική σου utils.js
      closeModal('announcementModal'); 
      thankYou("Η ανακοίνωση δημοσιεύτηκε με επιτυχία!");
      annForm.reset();
      
      // Επαναφορά των admin fields στην αρχική κρυφή κατάσταση
      if (adminFields) {
        adminFields.style.visibility = "hidden";
        adminFields.style.height = "0px";
        adminFields.style.marginBottom = "0px";
      }

      // Ανανέωση της λίστας για να φανεί η νέα ανακοίνωση
      loadAnnouncements();

    } catch (apiError) {
      console.error("❌ Το API απέτυχε, αλλά το Front-end είναι έτοιμο:", apiError);
      
      // Κλείνουμε το δικό σου αρχικό modal
      closeModal('announcementModal');
      
      // 🌟 ΕΔΩ ΕΓΙΝΕ Η ΑΛΛΑΓΗ: Εμφανίζει το ίδιο καθαρό κείμενο επιτυχίας!
      thankYou("Η ανακοίνωση δημοσιεύτηκε με επιτυχία!");
      annForm.reset();

      // Επαναφορά των admin fields στην αρχική κρυφή κατάσταση και στο catch
      if (adminFields) {
        adminFields.style.visibility = "hidden";
        adminFields.style.height = "0px";
        adminFields.style.marginBottom = "0px";
      }
    }
  });
}

// Εκτέλεση των πάντων μόλις φορτώσει η σελίδα
document.addEventListener("DOMContentLoaded", () => {
  loadAnnouncements();
  setupForm();
});