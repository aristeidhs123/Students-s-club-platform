import { EventsAPI, ReviewsAPI } from "../connection_f_b/api.js";
import { thankYou } from "./utils.js";

export async function initCreateReview() {
    const result = await EventsAPI.getCompletedForReview(1);
    const select = document.getElementById("event-select");
    
    result.events.forEach(ev => {
        const opt = document.createElement("option");
        opt.value = ev.event_id;
        opt.textContent = ev.ev_title;
        select.appendChild(opt);
    });

    document.getElementById("submit-btn").addEventListener("click", async () => {
        const data = {
            user_id: 1,
            rating: document.getElementById("rating").value,
            description: document.getElementById("description").value
        };
        await ReviewsAPI.create(document.getElementById("event-select").value, data);
        document.getElementById("id02").style.display = "none";
        thankYou("Η αξιολόγησή σας υποβλήθηκε με επιτυχία!");
    });
}