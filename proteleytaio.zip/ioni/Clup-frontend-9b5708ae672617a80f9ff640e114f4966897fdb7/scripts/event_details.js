import { EventsAPI } from "../connection_f_b/api.js"; 
import { thankYou } from "./utils.js";               

console.log("🚀 Το event_details.js φορτώθηκε επιτυχώς!");

function setupActionButtons() {
  const partBtn = document.getElementById("participateBtn");
  const cancelBtn = document.getElementById("cancelParticipationBtn");
  const rateBtn = document.getElementById("rateEventBtn");

  // 1. Κουμπί: Δήλωση Συμμετοχής
  if (partBtn) {
    partBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      thankYou(); 

      try {
        const eventId = new URLSearchParams(window.location.search).get("id");
        if (eventId) {
          await EventsAPI.participate(eventId); 
        }
      } catch (err) {
        console.error("Σφάλμα συμμετοχής στο backend:", err);
      }
    });
  }

  // 2. Κουμπί: Ακύρωση Συμμετοχής
  if (cancelBtn) {
    cancelBtn.addEventListener("click", (e) => {
      e.preventDefault();
      thankYou(); 
    });
  }

  // 3. Κουμπί: Αξιολόγηση Εκδήλωσης
  if (rateBtn) {
    rateBtn.addEventListener("click", (e) => {
      e.preventDefault();
      const eventId = new URLSearchParams(window.location.search).get("id");
      window.location.href = `reviews.html?id=${eventId}`;
    });
  }
}

// Φόρτωση δεδομένων από το API
async function loadEventData() {
  const eventId = new URLSearchParams(window.location.search).get("id");
  if (!eventId) return;

  try {
    const event = await EventsAPI.getById(eventId);
    if (event?.data) {
      document.getElementById("eventTitle").textContent = event.data.ev_title;
    }
  } catch (error) {
    console.error("Σφάλμα φόρτωσης δεδομένων API:", error);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  setupActionButtons(); 
  loadEventData();      
});