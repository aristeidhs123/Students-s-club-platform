import { thankYou } from "./utils.js"; 

console.log("Το events.js φορτώθηκε επιτυχώς!");

function setupParticipationListener() {
  const list = document.getElementById("events-list");
  if (!list) return; 

  list.addEventListener("click", (e) => {
    if (e.target.classList.contains("participate-btn")) {
      e.preventDefault();
      thankYou(); 
    }
  });
}

function setupCreateEventForm() {
  const eventForm = document.getElementById("eventForm");
  if (!eventForm) return; 

  eventForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const typeInput = document.querySelector('input[name="event_type"]:checked');
    const eventType = typeInput ? typeInput.value : "open";
    const eventTitle = document.getElementById("event_title").value;

    console.log("Σύστημα: Έλεγχος διαθεσιμότητας χώρου και τοποθεσίας...");
    if (eventType === "open") {
      console.log("Εκτέλεση: Βασική Ροή (Ανοιχτή Εκδήλωση)");
    } else {
      console.log("Εκτέλεση: Εναλλακτική Ροή (Κλειστή Εκδήλωση)");
    }
    console.log(`Ειδοποίηση Admin: Στάλθηκε η φόρμα για την εκδήλωση "${eventTitle}".`);
    
    eventForm.reset();

    thankYou(undefined, () => {
      window.location.href = "events.html";
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  setupParticipationListener(); 
  setupCreateEventForm(); 
});