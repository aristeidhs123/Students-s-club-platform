export function thankYou(message, onConfirmCallback) {
    if (!document.querySelector('link[href*="utils.css"]')) {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = new URL('../styles/utils.css', import.meta.url).href;
        document.head.appendChild(link);
    }

    let modal = document.getElementById('successModal');
    
    if (!modal) {
        const modalDiv = document.createElement('div');
        modalDiv.id = 'successModal';
        modalDiv.className = 'modal-overlay';
        modalDiv.style.display = 'none'; 

        modalDiv.innerHTML = `
          <div class="modal-content">
            <div style="font-size: 50px;">✅</div>
            <h3 id="thankYouMessage">Η ενέργειά σας ολοκληρώθηκε με επιτυχία!</h3>
            <button class="modal-btn" id="closeSuccessBtn">ΟΚ</button>
          </div>
        `;
        
        document.body.appendChild(modalDiv);
        modal = modalDiv;
    }
    
    if (message && message.trim() !== "") {
        document.getElementById('thankYouMessage').innerText = message;
    } else {
        document.getElementById('thankYouMessage').innerText = "Η ενέργειά σας ολοκληρώθηκε με επιτυχία!";
    }
    
    modal.style.display = 'flex';

    const oldBtn = document.getElementById('closeSuccessBtn');
    const newBtn = oldBtn.cloneNode(true);
    oldBtn.replaceWith(newBtn);

    newBtn.addEventListener('click', () => {
        modal.style.display = 'none';
        if (typeof onConfirmCallback === "function") {
            onConfirmCallback();
        }
    });
}