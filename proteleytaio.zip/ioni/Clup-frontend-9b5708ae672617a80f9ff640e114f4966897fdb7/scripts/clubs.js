import { ClubsAPI } from "../connection_f_b/api.js";

// ==========================================================================
// 1. ΦΟΡΤΩΣΗ ΤΩΝ CLUBS (Ο κώδικας που προϋπήρχε στο αρχείο)
// ==========================================================================
async function loadClubs() {
  try {
    const result = await ClubsAPI.getAll();
    const clubs = result.data || [];

    const grid = document.getElementById("clubs-list");
    if (!grid) return;
    grid.innerHTML = "";

    clubs.forEach(club => {
      const card = document.createElement("div");
      card.className = "card card-blue";

      card.innerHTML = `
        <div class="card-top gradient-1"></div>
        <div class="card-content">
          <h3>${club.title}</h3>
          <p>${club.description}</p>

          <div class="tags">
            <span>Status: ${club.status}</span>
            <span>Manager: User #${club.manager_id}</span>
          </div>

          <button class="card-btn" data-id="${club.club_id}">
            View Club
          </button>

          <button class="secondary-btn join-btn" data-id="${club.club_id}">
            Join Club
          </button>
        </div>
      `;

      grid.appendChild(card);
    });

    attachJoinEvents();

  } catch (error) {
    console.error(error);
    const grid = document.getElementById("clubs-list");
    if (grid) {
      grid.innerHTML = "<p>Δεν ήταν δυνατή η φόρτωση των συλλόγων.</p>";
    }
  }
}

function attachJoinEvents() {
  document.querySelectorAll(".join-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      const clubId = btn.dataset.id;
      await ClubsAPI.join(clubId);
      alert("Αίτηση συμμετοχής στάλθηκε!");
    });
  });
}


// ==========================================================================
// ΛΕΙΤΟΥΡΓΙΑ ΓΙΑ ΤΟ POP-UP (ΔΗΜΙΟΥΡΓΙΑ CLUB)
// ==========================================================================
function setupCreateClubModal() {
  const modalCreateClub = document.getElementById("id04");
  const openCreateClubBtn = document.getElementById("openCreateClub");

  // Ανοίγει το παράθυρο ΜΟΝΟ όταν πατηθεί το κουμπί
  if (openCreateClubBtn && modalCreateClub) {
    openCreateClubBtn.addEventListener("click", (e) => {
      e.preventDefault(); // Σταματάει οποιοδήποτε περίεργο reload
      modalCreateClub.style.setProperty("display", "flex", "important");
    });
  }

  // Κλείνει το παράθυρο αν πατήσεις έξω από το μαύρο φόντο
  window.addEventListener("click", (event) => {
    if (modalCreateClub && event.target === modalCreateClub) {
      modalCreateClub.style.setProperty("display", "none", "important");
    }
  });
}

// Εκκίνηση όταν φορτώσει η σελίδα
document.addEventListener("DOMContentLoaded", () => {
  setupCreateClubModal();
});

import { thankYou } from '../scripts/utils.js'; // Εισαγωγή της συνάρτησης

// Εκεί που είναι το submit της φόρμας σου:
document.getElementById('clubForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // ... εδώ θα είναι ο κώδικας που στέλνει τα δεδομένα στο API ...

    // Και στο τέλος, εμφανίζεις το pop-up:
    thankYou("Πραγματοποιήθηκε η καταχώριση");
});