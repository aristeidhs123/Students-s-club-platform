import { ReviewsAPI } from "../connection_f_b/api.js";

// Φόρτωση αρχικών reviews
async function loadReviews() {
    try {
        const result = await ReviewsAPI.getPublic(1);
        const list = document.getElementById("reviews-list");
        if(list) {
            list.innerHTML = (result.reviews || []).map(r => `
                <div class="review-item">
                    <h4>${r.name} ${r.lastname}</h4>
                    <p>Rating: ${r.r_review}</p>
                    <p>${r.r_descr}</p>
                </div>
            `).join('');
        }
    } catch (e) { 
        console.error("Σφάλμα API:", e); 
    }
}

document.addEventListener("DOMContentLoaded", loadReviews);

// --- ΕΔΩ ΕΙΝΑΙ Η ΑΛΛΑΓΗ ΓΙΑ ΤΟ ΚΟΥΜΠΙ ΣΟΥ ---

// Φτιάχνουμε τη συνάρτηση openModal και την "κολλάμε" στο window 
// για να μπορεί να τη δεί το onclick="openModal()" του HTML σου!
window.openModal = async function() {
    const wrapper = document.getElementById("modal-wrapper");
    if (wrapper && wrapper.innerHTML === "") {
        const res = await fetch('./review_create.html');
        wrapper.innerHTML = await res.text();
        
        const { initCreateReview } = await import('./create_review.js');
        initCreateReview();
    }
    
    const modal = document.getElementById("id02");
    if (modal) {
        modal.style.display = "block";
    }
}