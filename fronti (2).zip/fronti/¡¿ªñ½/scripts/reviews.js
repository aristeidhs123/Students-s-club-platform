import { ReviewsAPI } from "../connection_f_b/api.js";

async function loadReviews() {
    const list = document.getElementById("reviews-list");
    if (!list) return;

    try {
        const result = await ReviewsAPI.getPublic(1);
        const reviews = result.reviews || result.data || [];

        list.innerHTML = "";

        if (reviews.length === 0) {
            list.innerHTML = `<p style="color: #bbb; text-align: center;">Δεν υπάρχουν ακόμη αξιολογήσεις.</p>`;
            return;
        }

        reviews.forEach((r, index) => {
            const card = document.createElement("div");
            
            if (index % 2 === 0) {
                card.className = "card card-cyan";
                card.innerHTML = `<div class="card-top gradient-3"></div>`;
            } else {
                card.className = "card card-purple";
                card.innerHTML = `<div class="card-top gradient-2"></div>`;
            }

            const content = document.createElement("div");
            content.className = "card-content";

            const ratingVal = parseInt(r.r_review || r.rating) || 5;
            const stars = "⭐".repeat(ratingVal);

            content.innerHTML = `
                <h3>${r.name || ""} ${r.lastname || "User"}</h3>
                <p style="font-size: 18px; margin: 5px 0;">${stars}</p>
                <p>${r.r_descr || r.description || ""}</p>
            `;

            card.appendChild(content);
            list.appendChild(card);
        });

    } catch (error) {
        console.error(error);
        list.innerHTML = "<p style='color: #ff4a4a; text-align: center;'>Σφάλμα φόρτωσης αξιολογήσεων από το backend.</p>";
    }
}

document.addEventListener("DOMContentLoaded", () => {
    loadReviews();
});