export function thankYou(message, onConfirmCallback) {
    if (!document.querySelector('link[href*="utils.css"]')) {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = new URL('../styles/utils.css', import.meta.url).href;
        document.head.appendChild(link);
    }

    let modal = document.getElementById('successModal');
    
    if (!modal) {
        const modalDiv = document.createElement('div');
        modalDiv.id = 'successModal';
        modalDiv.className = 'modal-overlay';
        
        modalDiv.style.position = 'fixed';
        modalDiv.style.zIndex = '10000';
        modalDiv.style.left = '0';
        modalDiv.style.top = '0';
        modalDiv.style.width = '100vw';
        modalDiv.style.height = '100vh';
        modalDiv.style.backgroundColor = 'rgba(0, 0, 0, 0.75)';
        modalDiv.style.display = 'none'; 
        modalDiv.style.alignItems = 'center';      
        modalDiv.style.justifyContent = 'center';   

        modalDiv.innerHTML = `
          <div class="modal-content" style="background-color: #1a1a2e; color: white; padding: 40px; border-radius: 12px; border: 2px solid #45f3ff; text-align: center; box-shadow: 0 4px 25px rgba(0,0,0,0.7); max-width: 400px; width: 85%;">
            <div style="font-size: 50px; margin-bottom: 15px;">✅</div>
            <h3 id="thankYouMessage" style="color: #45f3ff; margin-bottom: 20px;">Η ενέργειά σας ολοκληρώθηκε με επιτυχία!</h3>
            <button class="modal-btn" id="closeSuccessBtn" style="padding: 10px 30px; background: #28a745; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; font-size: 16px;">ΟΚ</button>
          </div>
        `;
        
        document.body.appendChild(modalDiv);
        modal = modalDiv;
    }
    
    if (message && message.trim() !== "") {
        document.getElementById('thankYouMessage').innerText = message;
    } else {
        document.getElementById('thankYouMessage').innerText = "Η ενέργειά σας ολοκληρώθηκε με επιτυχία!";
    }
    
    modal.style.setProperty("display", "flex", "important");

    const oldBtn = document.getElementById('closeSuccessBtn');
    const newBtn = oldBtn.cloneNode(true);
    oldBtn.replaceWith(newBtn);

    newBtn.addEventListener('click', () => {
        modal.style.display = 'none';
        if (typeof onConfirmCallback === "function") {
            onConfirmCallback();
        }
    });
}

export function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = "none";
    }
}