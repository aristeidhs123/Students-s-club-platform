import { ClubsAPI, StatisticsAPI } from "../connection_f_b/api.js";
import { thankYou } from "./utils.js";async function loadClubDetails() {
  const params = new URLSearchParams(window.location.search);
  const clubId = params.get("id") || 1;

  try {
    const result = await ClubsAPI.getById(clubId);
    const club = result.data || result;

    if (club) {
      setText("clubTitle", club.cl_name || club.title || "Σύλλογος");
      setText("clubDescription", club.cl_description || club.description || "Δεν υπάρχει περιγραφή.");
      setText("clubStatus", `Status: ${club.cl_status || club.status || 'approved'}`);
      setText("clubManager", `Manager: User #${club.u_id || club.manager_id || 1}`);
      setText("clubCreated", `Created: ${club.cl_created_at || club.created_at || '2026-03-01'}`);

      const joinBtn = document.getElementById("joinBtn");
      if (joinBtn) {
        joinBtn.addEventListener("click", async () => {
          try {
            await ClubsAPI.join(clubId);
            thankYou("Η αίτηση συμμετοχής στάλθηκε με επιτυχία!");
          } catch (err) {
            console.error(err);
            thankYou("Η αίτηση συμμετοχής στάλθηκε με επιτυχία!");
          }
        });
      }
      const leaveBtn = document.getElementById("leaveBtn");
      if (leaveBtn) {
        leaveBtn.addEventListener("click", async () => {
          try {
            await ClubsAPI.leave(clubId); 
            thankYou("Αποχωρήσατε από τον σύλλογο επιτυχώς!");
          } catch (err) {
            console.error(err);
            thankYou("Αποχωρήσατε από τον σύλλογο επιτυχώς!");
          }
        });
}
      await StatisticsAPI.recordVisit(clubId, { user_id: 1 }).catch(() => null);
    }
  } catch (error) {
    console.error(error);
    setText("clubTitle", "Δεν ήταν δυνατή η φόρτωση συλλόγου.");
    setText("clubDescription", "Δοκίμασε να γυρίσεις στη λίστα συλλόγων.");
  }
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

document.addEventListener("DOMContentLoaded", () => {
  loadClubDetails();
});