import { EventsAPI } from "../connection_f_b/api.js";
import { thankYou } from "./utils.js";

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("eventForm");
    if (!form) return;

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const typeRadio = document.querySelector('input[name="event_type"]:checked');
        const titleInput = document.getElementById("event_title");
        const descInput = document.getElementById("event_descr");
        const locationInput = document.getElementById("event_location");
        const seatsInput = document.getElementById("event_seats");
        const startInput = document.getElementById("event_start");

        const title = titleInput ? titleInput.value.trim() : "";
        const description = descInput ? descInput.value.trim() : "";
        const location = locationInput ? locationInput.value.trim() : "";
        const seats = seatsInput ? seatsInput.value : 0;
        const starttime = startInput ? startInput.value : "";
        const eventType = typeRadio ? typeRadio.value : "open";

        if (!title || !description || !location || !starttime) {
            alert("Συμπλήρωσε τίτλο, περιγραφή, τοποθεσία και ημερομηνία.");
            return;
        }

        const start = starttime.replace("T", " ") + ":00";
        const endDate = new Date(starttime);
        endDate.setHours(endDate.getHours() + 2);
        const end = endDate.toISOString().slice(0, 19).replace("T", " ");

        try {
            await EventsAPI.create({
                evclubid: 1,
                title,
                description,
                role: eventType,
                seats,
                location,
                gplatos: 38.246242,
                gmikos: 21.735084,
                starttime: start,
                endtime: end
            });

            form.reset();
            thankYou("Η εκδήλωση δημιουργήθηκε με επιτυχία!");

            setTimeout(() => {
                window.location.href = "events.html";
            }, 2000);
        } catch (error) {
            console.error(error);
            form.reset();
            thankYou("Η εκδήλωση δημιουργήθηκε με επιτυχία!");

            setTimeout(() => {
                window.location.href = "events.html";
            }, 2000);
        }
    });
});