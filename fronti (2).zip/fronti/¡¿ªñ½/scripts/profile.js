import { ProfileAPI, getCurrentUser, getCurrentUserId } from "../connection_f_b/api.js";
import { thankYou } from "./utils.js";
async function loadProfile() {
  const user = getCurrentUser();
  const userId = getCurrentUserId();

  try {
    const result = await ProfileAPI.get(userId);
    const profile = result.data || result.profile || user;

    setText("name", `${profile.name || ""} ${profile.lastname || ""}`.trim() || "Χρήστης");
    setText("email", profile.email || "-");
    setText("role", profile.role || "user");
    setText("interests", profile.user_interests || "Δεν έχουν συμπληρωθεί.");
    setText("bio", profile.user_bio || "Δεν έχει συμπληρωθεί περιγραφή.");

    const nameInput = document.getElementById("profile-name-input") || document.querySelector('input[name="name"]');
    const lastnameInput = document.getElementById("profile-lastname-input") || document.querySelector('input[name="lastname"]');
    const emailInput = document.getElementById("profile-email-input") || document.querySelector('input[name="email"]');
    const bioInput = document.getElementById("profile-bio-input") || document.querySelector('textarea[name="bio"]');
    const interestsInput = document.getElementById("profile-interests-input") || document.querySelector('input[name="interests"]');

    if (nameInput) nameInput.value = profile.name || "";
    if (lastnameInput) lastnameInput.value = profile.lastname || "";
    if (emailInput) emailInput.value = profile.email || "";
    if (bioInput) bioInput.value = profile.user_bio || "";
    if (interestsInput) interestsInput.value = profile.user_interests || "";

  } catch (error) {
    console.error(error);
    setText("name", "Δεν ήταν δυνατή η φόρτωση προφίλ.");
  }
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

async function saveProfile(event) {
  event.preventDefault();
  const userId = getCurrentUserId();
  const bioInput = document.getElementById("profile-bio-input") || document.querySelector('textarea[name="bio"]');
  const interestsInput = document.getElementById("profile-interests-input") || document.querySelector('input[name="interests"]');

  try {
    if (bioInput) await ProfileAPI.updateBio(userId, bioInput.value);
    if (interestsInput) await ProfileAPI.updateInterests(userId, interestsInput.value);
    thankYou("Το προφίλ ενημερώθηκε με επιτυχία!");    await loadProfile();
  } catch (error) {
    alert("Σφάλμα αποθήκευσης προφίλ.");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadProfile();
  const form = document.getElementById("profile-form") || document.querySelector("form");
  if (form) form.addEventListener("submit", saveProfile);
});
