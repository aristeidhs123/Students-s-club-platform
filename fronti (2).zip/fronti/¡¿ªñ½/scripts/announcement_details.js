import { AnnouncementsAPI } from "../connection_f_b/api.js";

document.addEventListener("DOMContentLoaded", async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const announcementId = urlParams.get('id');

  if (!announcementId) {
    document.getElementById("annTitle").textContent = "Σφάλμα";
    document.getElementById("annDescr").textContent = "Η ανακοίνωση δεν βρέθηκε.";
    return;
  }

  try {
    const response = await AnnouncementsAPI.getById(announcementId);
    const announcement = response.data || response;

    if (announcement) {
      document.getElementById("annTitle").textContent = announcement.an_title || announcement.title || "Χωρίς Τίτλο";
      document.getElementById("annDescr").textContent = announcement.an_content || announcement.content || "Χωρίς Περιεχόμενο";
      document.getElementById("annClub").textContent = announcement.cl_name || announcement.club_name || "Tech Club";
      document.getElementById("annDate").textContent = announcement.an_date || announcement.date || "2026-05-30";
      document.getElementById("annAuthor").textContent = announcement.u_username || announcement.author || `User #${announcement.u_id || 1}`;
      document.getElementById("annVisibility").textContent = announcement.an_visibility || announcement.visibility || "Public";
    }
  } catch (error) {
    console.error(error);
    document.getElementById("annTitle").textContent = "Αποτυχία Σύνδεσης";
    document.getElementById("annDescr").textContent = "Δεν ήταν δυνατή η άντληση της ανακοίνωσης από τη βάση δεδομένων.";
  }
});