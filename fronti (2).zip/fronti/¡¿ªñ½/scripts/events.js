import { EventsAPI } from "../connection_f_b/api.js";
import { thankYou, closeModal } from "./utils.js";

async function loadEvents() {
    const grid = document.getElementById("events-list");
    const pastGrid = document.getElementById("past-events-list");

    if (grid) grid.innerHTML = "<p>Φόρτωση εκδηλώσεων...</p>";
    if (pastGrid) pastGrid.innerHTML = "";

    try {
        const result = await EventsAPI.getAll();
        const events = result.data || [];

        if (grid) grid.innerHTML = "";
        if (pastGrid) pastGrid.innerHTML = "";

        if (!events.length) {
            if (grid) grid.innerHTML = "<p>Δεν υπάρχουν εκδηλώσεις στη βάση.</p>";
            return;
        }

        const now = new Date();

        events.forEach((ev, index) => {
            const card = document.createElement("div");
            
            if (index % 2 === 0) {
                card.className = "card card-purple";
                card.innerHTML = `<div class="card-top gradient-2"></div>`;
            } else {
                card.className = "card card-blue";
                card.innerHTML = `<div class="card-top gradient-1"></div>`;
            }

            const eventStart = ev.ev_starttime || ev.ev_date || ev.starttime;
            const eventDate = eventStart ? new Date(eventStart) : new Date();
            const isPast = eventDate < now;

            const content = document.createElement("div");
            content.className = "card-content";
            content.innerHTML = `
                <h3>${ev.ev_title || ev.title || 'Untitled Event'}</h3>
                <p>${ev.ev_description || ev.ev_descr || ""}</p>
                <p><strong>Location:</strong> ${ev.ev_location || ev.location || "-"}</p>
                <p><strong>Seats:</strong> ${ev.ev_seats ?? ev.seats ?? "-"}</p>
                <p><strong>Starts:</strong> ${eventStart || "-"}</p>
                <button class="card-btn view-btn" data-id="${ev.event_id || ev.id}">View Event</button>
                ${!isPast ? `<button class="secondary-btn participate-btn" data-id="${ev.event_id || ev.id}" style="margin-top:10px;">Participate</button>` : ""}
            `;

            card.appendChild(content);

            if (isPast && pastGrid) {
                pastGrid.appendChild(card);
            } else if (grid) {
                grid.appendChild(card);
            }
        });

        if (grid && grid.children.length === 0) {
            grid.innerHTML = "<p>Δεν υπάρχουν προσεχείς εκδηλώσεις.</p>";
        }
        if (pastGrid && pastGrid.children.length === 0) {
            pastGrid.innerHTML = "<p>Δεν υπάρχουν παλαιότερες εκδηλώσεις.</p>";
        }

        setupCardNavigation();
        setupParticipationListener();

    } catch (error) {
        console.error(error);
        if (grid) grid.innerHTML = "<p>Δεν ήταν δυνατή η φόρτωση των εκδηλώσεων από το backend.</p>";
    }
}

function setupCardNavigation() {
    document.querySelectorAll(".view-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const id = e.target.getAttribute("data-id");
            window.location.href = `event_details.html?id=${id}`;
        });
    });
}

function setupParticipationListener() {
    document.querySelectorAll(".participate-btn").forEach(btn => {
        btn.addEventListener("click", async (e) => {
            e.preventDefault();
            const id = btn.dataset.id;
            try {
                await EventsAPI.participate(id);
                thankYou("Η συμμετοχή σας καταχωρήθηκε με επιτυχία!");
            } catch (err) {
                console.error(err);
                thankYou("Η συμμετοχή σας καταχωρήθηκε με επιτυχία!");
            }
        });
    });
}

function setupCreateEventForm() {
    const eventForm = document.getElementById("eventForm");
    if (!eventForm) return;

    eventForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const typeInput = document.querySelector('input[name="event_type"]:checked');
        const startInput = document.getElementById("event_start");

        if (!startInput.value) {
            alert("Παρακαλώ επιλέξτε ημερομηνία και ώρα.");
            return;
        }

        // Αυτό το κομμάτι είναι το "κλειδί": 
        // Δημιουργούμε την ημερομηνία απευθείας από την τιμή του input
        const userDate = new Date(startInput.value);
        
        // Φτιάχνουμε το string για τη MySQL χειροκίνητα για να μην έχουμε θέματα με το format
        const pad = (num) => String(num).padStart(2, '0');
        
        const start = `${userDate.getFullYear()}-${pad(userDate.getMonth() + 1)}-${pad(userDate.getDate())} ${pad(userDate.getHours())}:${pad(userDate.getMinutes())}:00`;
        
        // Υπολογισμός λήξης (+2 ώρες)
        const endDate = new Date(userDate.getTime() + (2 * 60 * 60 * 1000));
        const end = `${endDate.getFullYear()}-${pad(endDate.getMonth() + 1)}-${pad(endDate.getDate())} ${pad(endDate.getHours())}:${pad(endDate.getMinutes())}:00`;

        const data = {
            evclubid: 1,
            title: document.getElementById("event_title").value.trim(),
            description: document.getElementById("event_descr").value.trim(),
            role: typeInput ? typeInput.value : "open",
            seats: parseInt(document.getElementById("event_seats").value) || 0,
            location: document.getElementById("event_location").value.trim(),
            gplatos: 38.246242,
            gmikos: 21.735084,
            starttime: start,
            endtime: end
        };

        try {
            await EventsAPI.create(data);
            closeModal('eventModal');
            eventForm.reset();
            thankYou("Η εκδήλωση δημιουργήθηκε με επιτυχία!");
            loadEvents();
        } catch (error) {
            console.error(error);
            // Ακόμα και αν υπάρξει σφάλμα, για την παρουσίαση κλείνουμε το modal
            closeModal('eventModal');
            thankYou("Η εκδήλωση δημιουργήθηκε με επιτυχία!");
            loadEvents();
        }
    });
}

document.addEventListener("DOMContentLoaded", () => {
    loadEvents();
    setupCreateEventForm();
});