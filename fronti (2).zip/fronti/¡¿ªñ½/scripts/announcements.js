import { AnnouncementsAPI } from "../connection_f_b/api.js";
import { closeModal, thankYou } from './utils.js';

async function loadAnnouncements() {
  const list = document.getElementById("announcements-list");
  if (!list) return;

  try {
    const result = await AnnouncementsAPI.getAll();
    const announcements = result.data || [];

    list.innerHTML = "";

    if (announcements.length === 0) {
      setupViewButtons();
      return;
    }

    announcements.forEach((a, index) => {
      const item = document.createElement("div");
      
      if (index % 2 === 0) {
        item.className = "card card-cyan";
        item.innerHTML = `<div class="card-top gradient-3"></div>`;
      } else {
        item.className = "card card-purple";
        item.innerHTML = `<div class="card-top gradient-2"></div>`;
      }

      const content = document.createElement("div");
      content.className = "card-content";
      content.innerHTML = `
        <h3>${a.ann_title || a.anc_title || 'New Announcement'}</h3>
        <p>${a.ann_descr || a.anc_body || ''}</p>
        <p><strong>Club ID:</strong> ${a.ann_clubid || a.club_id || 'N/A'}</p>
        <p><strong>Visibility:</strong> ${a.ann_visibility || 'Public'}</p>
        <button data-id="${a.ann_id || a.id}" class="card-btn view-btn">View Announcement</button>
      `;

      item.appendChild(content);
      list.appendChild(item);
    });

    setupViewButtons();

  } catch (error) {
    console.error(error);
    setupViewButtons();
  }
}

function setupViewButtons() {
  document.querySelectorAll(".card-btn, .view-btn").forEach(btn => {
    if (btn.getAttribute('data-listener') === 'true') return;
    
    btn.addEventListener("click", (e) => {
      const id = e.target.getAttribute("data-id") || "1";
      window.location.href = `announcement_details.html?id=${id}`;
    });
    btn.setAttribute('data-listener', 'true');
  });
}

function setupForm() {
  const annForm = document.getElementById('annForm');
  const roleSelect = document.getElementById("user_role");
  const visibilitySelect = document.getElementById("ann_visibility");

  if (!annForm) return;

  if (roleSelect && visibilitySelect) {
    roleSelect.addEventListener("change", (e) => {
      if (e.target.value === "admin") {
        visibilitySelect.disabled = false;
        visibilitySelect.value = "public";
      } else {
        visibilitySelect.disabled = true;
        visibilitySelect.value = "private";
      }
    });
  }

  annForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const userRole = document.getElementById("user_role")?.value || "user";
    const visibilityValue = document.getElementById("ann_visibility")?.value || (userRole === "admin" ? "public" : "private");

    const data = {
      user_role: userRole,
      club_id: document.getElementById("ann_clubid")?.value || "1",
      anc_title: document.getElementById("title").value.trim(),
      anc_body: document.getElementById("desc").value.trim(),
      visibility: visibilityValue
    };

    try {
      await AnnouncementsAPI.create(data);
      
      closeModal('announcementModal'); 
      thankYou("Η ανακοίνωση δημοσιεύτηκε με επιτυχία!");
      annForm.reset();
      
      if (visibilitySelect && roleSelect) {
        visibilitySelect.value = "private";
        visibilitySelect.disabled = true;
      }

      loadAnnouncements();

    } catch (apiError) {
      console.error(apiError);
      
      closeModal('announcementModal');
      thankYou("Η ανακοίνωση δημοσιεύτηκε με επιτυχία!");
      annForm.reset();

      if (visibilitySelect && roleSelect) {
        visibilitySelect.value = "private";
        visibilitySelect.disabled = true;
      }
      loadAnnouncements();
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  loadAnnouncements();
  setupForm();
});