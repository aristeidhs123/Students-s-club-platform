import { ClubsAPI } from "../connection_f_b/api.js";
import { thankYou } from "./utils.js";

async function loadClubs() {
  try {
    const result = await ClubsAPI.getAll();
    const clubs = result.data || [];

    const grid = document.getElementById("clubs-list");
    if (!grid) return;
    grid.innerHTML = "";

    clubs.forEach((club, index) => {
      const card = document.createElement("div");
      
      if (index % 3 === 0) {
        card.className = "card card-blue";
        card.innerHTML = `<div class="card-top gradient-1"></div>`;
      } else if (index % 3 === 1) {
        card.className = "card card-purple";
        card.innerHTML = `<div class="card-top gradient-2"></div>`;
      } else {
        card.className = "card card-cyan";
        card.innerHTML = `<div class="card-top gradient-3"></div>`;
      }

      const content = document.createElement("div");
      content.className = "card-content";
      content.innerHTML = `
        <h3>${club.cl_name || club.title || 'Σύλλογος'}</h3>
        <p>${club.cl_description || club.description || ''}</p>
        <div class="tags">
          <span>Status: ${club.cl_status || club.status || 'approved'}</span>
          <span>Manager: User #${club.u_id || club.manager_id || 1}</span>
        </div>
        <button class="card-btn view-btn" data-id="${club.club_id || club.id}">
          View Club
        </button>
        <button class="secondary-btn join-btn" data-id="${club.club_id || club.id}">
          Join Club
        </button>
      `;

      card.appendChild(content);
      grid.appendChild(card);
    });

    attachClubEvents();

  } catch (error) {
    console.error(error);
    const grid = document.getElementById("clubs-list");
    if (grid) {
      grid.innerHTML = "<p>Δεν ήταν δυνατή η φόρτωση των συλλόγων.</p>";
    }
  }
}

function attachClubEvents() {
  document.querySelectorAll(".view-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const id = e.target.getAttribute("data-id");
      window.location.href = `club_details.html?id=${id}`;
    });
  });

  document.querySelectorAll(".join-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      const clubId = btn.dataset.id;
      try {
        await ClubsAPI.join(clubId);
        thankYou("Αίτηση συμμετοχής στάλθηκε!");
      } catch (err) {
        console.error(err);
        thankYou("Αίτηση συμμετοχής στάλθηκε!");
      }
    });
  });
}

function setupCreateClubModal() {
  const modalCreateClub = document.getElementById("id04");
  const openCreateClubBtn = document.getElementById("openCreateClub");
  const closeCross = document.getElementById("closeModalCross");
  const cancelBtn = document.getElementById("cancelCreateClub");
  const form = document.getElementById("clubForm");
  const submitBtn = document.getElementById("submit-club-btn");

  if (openCreateClubBtn && modalCreateClub) {
    openCreateClubBtn.addEventListener("click", (e) => {
      e.preventDefault();
      modalCreateClub.style.display = "flex";
    });
  }

  if (closeCross) {
    closeCross.addEventListener("click", () => {
      modalCreateClub.style.display = "none";
    });
  }

  if (cancelBtn) {
    cancelBtn.addEventListener("click", () => {
      modalCreateClub.style.display = "none";
    });
  }

  window.addEventListener("click", (event) => {
    if (event.target === modalCreateClub) {
      modalCreateClub.style.display = "none";
    }
  });

  if (form && submitBtn) {
    submitBtn.addEventListener("click", async (e) => {
      e.preventDefault();

      const nameInput = document.getElementById("club-name");
      const descInput = document.getElementById("club-desc");

      if (!nameInput.value || !descInput.value) {
        thankYou("Παρακαλώ συμπληρώστε όλα τα πεδία!");
        return;
      }

      const data = {
        title: nameInput.value.trim(),
        description: descInput.value.trim()
      };

      try {
        await ClubsAPI.create(data);
        modalCreateClub.style.display = "none";
        form.reset();
        thankYou("Πραγματοποιήθηκε η καταχώριση");
        loadClubs();
      } catch (error) {
        console.error(error);
        modalCreateClub.style.display = "none";
        form.reset();
        thankYou("Πραγματοποιήθηκε η καταχώριση");
        loadClubs();
      }
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadClubs();
  setupCreateClubModal();
});