import { thankYou } from "./utils.js";
document.addEventListener("DOMContentLoaded", () => {
    const chatWindow = document.getElementById("chatWindow");
    const chatInput = document.getElementById("chatInput");
    const sendBtn = document.getElementById("sendMessageBtn");
    const contactAdminBtn = document.getElementById("contactAdminBtn");
    const contactForm = document.getElementById("contactForm");

    // 1. Λειτουργία Chat (Απλή)
    sendBtn.addEventListener("click", () => {
        const message = chatInput.value.trim();
        if (message) {
            const userMsg = document.createElement("p");
            userMsg.innerHTML = `<strong>Εσύ:</strong> ${message}`;
            chatWindow.appendChild(userMsg);
            
            chatInput.value = "";
            chatWindow.scrollTop = chatWindow.scrollHeight;

            // Απάντηση Bot
            setTimeout(() => {
                const botMsg = document.createElement("p");
                botMsg.innerHTML = `<strong>Chatbot:</strong> Έλαβα το μήνυμά σου: "${message}".`;
                chatWindow.appendChild(botMsg);
                chatWindow.scrollTop = chatWindow.scrollHeight;
            }, 500);
        }
    });

    // 2. Εμφάνιση Φόρμας Admin
    contactAdminBtn.addEventListener("click", () => {
        contactForm.style.display = contactForm.style.display === "none" ? "block" : "none";
    });
});
const sendAdminBtn = document.getElementById("sendAdminBtn");

sendAdminBtn.addEventListener("click", () => {
    const name = document.getElementById("adminName").value;
    const msg = document.getElementById("adminMsg").value;

    if (!name || !msg) {
        thankYou("Παρακαλώ συμπληρώστε τα πεδία!");
        return;
    }

    // Εδώ καλείς το API σου ή εμφανίζεις ένα μήνυμα
thankYou("Επιτυχής καταχώριση! Το μήνυμά σας στάλθηκε στον Admin.");    
    // Καθαρισμός και κλείσιμο φόρμας
    document.getElementById("contactForm").style.display = "none";
    document.getElementById("adminName").value = "";
    document.getElementById("adminMsg").value = "";
});
