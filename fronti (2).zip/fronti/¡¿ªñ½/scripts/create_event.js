import { EventsAPI } from "../connection_f_b/api.js"; // Ή το αντίστοιχο ReviewsAPI
import { thankYou } from "./utils.js";

document.addEventListener("DOMContentLoaded", async () => {
    const eventSelect = document.getElementById("event-select");
    const submitBtn = document.getElementById("submit-btn");

    // 1. Φόρτωση όλων των εκδηλώσεων στο dropdown (για να επιλέξει ο χρήστης)
    try {
        const events = await EventsAPI.getAll(); 
        const list = events.data || [];
        list.forEach(ev => {
            const option = document.createElement("option");
            option.value = ev.event_id || ev.id;
            option.textContent = ev.ev_title || ev.title;
            eventSelect.appendChild(option);
        });
    } catch (err) {
        console.error("Σφάλμα φόρτωσης events:", err);
    }

    // 2. Υποβολή αξιολόγησης
    submitBtn.addEventListener("click", async () => {
        const eventId = eventSelect.value;
        const rating = document.getElementById("rating").value;
        const description = document.getElementById("description").value.trim();

        if (!eventId || !rating || !description) {
            alert("Παρακαλώ συμπληρώστε όλα τα πεδία!");
            return;
        }

        try {
            // Προσαρμόζεις το αντικείμενο ανάλογα με το τι περιμένει το backend σου
            await EventsAPI.createReview({
                event_id: eventId,
                rating: parseInt(rating),
                review_text: description
            });

            thankYou("Η αξιολόγησή σας υποβλήθηκε επιτυχώς!");
            setTimeout(() => window.location.href = 'reviews.html', 1500);
        } catch (err) {
            console.error("Σφάλμα αποστολής:", err);
            alert("Σφάλμα κατά την αποστολή της αξιολόγησης.");
        }
    });
});