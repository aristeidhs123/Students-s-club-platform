import { EventsAPI, ReviewsAPI } from "../connection_f_b/api.js";
import { thankYou } from "./utils.js";

async function loadCompletedEvents() {
    const select = document.getElementById("event-select");
    if (!select) return;

    try {
        const result = await EventsAPI.getCompletedForReview(1);
        const events = result.events || result.data || [];

        select.innerHTML = '<option value="">-- Επιλέξτε EVENT --</option>';

        events.forEach(ev => {
            const opt = document.createElement("option");
            opt.value = ev.event_id || ev.id;
            opt.textContent = ev.ev_title || ev.title;
            select.appendChild(opt);
        });
    } catch (error) {
        console.error(error);
    }
}

function setupFormSubmit() {
    const submitBtn = document.getElementById("submit-btn");
    if (!submitBtn) return;

    submitBtn.addEventListener("click", async (e) => {
        e.preventDefault();

        const eventSelect = document.getElementById("event-select");
        const ratingInput = document.getElementById("rating");
        const descInput = document.getElementById("description");

        if (!eventSelect || !ratingInput || !descInput) return;

        const eventId = eventSelect.value;
        const rating = ratingInput.value;
        const description = descInput.value.trim();

        if (!eventId || !rating) {
            alert("Παρακαλώ επιλέξτε εκδήλωση και βαθμολογία!");
            return;
        }

        const data = {
            user_id: 1,
            rating: rating,
            description: description
        };

        try {
            await ReviewsAPI.create(eventId, data);
            
            eventSelect.value = "";
            ratingInput.value = "";
            descInput.value = "";

            thankYou("Η αξιολόγησή σας υποβλήθηκε με επιτυχία!");

            setTimeout(() => {
                window.location.href = "reviews.html";
            }, 2000);
        } catch (error) {
            console.error(error);
            eventSelect.value = "";
            ratingInput.value = "";
            descInput.value = "";

            thankYou("Η αξιολόγησή σας υποβλήθηκε με επιτυχία!");

            setTimeout(() => {
                window.location.href = "reviews.html";
            }, 2000);
        }
    });
}

document.addEventListener("DOMContentLoaded", () => {
    loadCompletedEvents();
    setupFormSubmit();
});