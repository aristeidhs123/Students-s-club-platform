export function thankYou(message) {
    // Αν το modal δεν υπάρχει ήδη στη σελίδα, το δημιουργούμε
    if (!document.getElementById('successModal')) {
        const modalHTML = `
        <div id="successModal" class="modal-overlay">
          <div class="modal-content">
            <div style="font-size: 50px;">✅</div>
            <h3 id="thankYouMessage">${message}</h3>
            <button class="modal-btn" onclick="document.getElementById('successModal').style.display='none'">ΟΚ</button>
          </div>
        </div>`;
        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }
    
    // Αλλάζουμε το κείμενο και το εμφανίζουμε
    document.getElementById('thankYouMessage').innerText = message;
    document.getElementById('successModal').style.display = 'flex';
}

// utils.js

// Συνάρτηση για άνοιγμα οποιουδήποτε modal
export function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = "block"; // Ή 'flex', ανάλογα με το CSS σου
    }
}

// Συνάρτηση για κλείσιμο οποιουδήποτε modal
export function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = "none";
    }
}

// Η συνάρτηση για το μήνυμα επιτυχίας που φτιάξαμε πριν
export function thankYou(message) {
    // ... (ο κώδικας που είχαμε) ...
}

