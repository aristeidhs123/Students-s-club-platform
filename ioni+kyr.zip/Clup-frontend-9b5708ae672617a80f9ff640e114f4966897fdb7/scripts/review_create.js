import { EventsAPI, ReviewsAPI } from "../connection_f_b/api.js";

async function loadCompletedEvents() {
  const userId = 1;

  const result = await EventsAPI.getCompletedForReview(userId);
  const events = result.events || [];

  const select = document.getElementById("event-select");

  events.forEach(ev => {
    const opt = document.createElement("option");
    opt.value = ev.event_id;
    opt.textContent = ev.ev_title;
    select.appendChild(opt);
  });
}

async function submitReview() {
  const eventId = document.getElementById("event-select").value;
  const rating = document.getElementById("rating").value;
  const description = document.getElementById("description").value;

  await ReviewsAPI.create(eventId, {
    user_id: 1,
    rating,
    description
  });

  alert("Η αξιολόγηση υποβλήθηκε!");
}

document.addEventListener("DOMContentLoaded", loadCompletedEvents);
document.getElementById("submit-btn").addEventListener("click", submitReview);


// Στο αρχείο reviews.js
document.addEventListener("DOMContentLoaded", () => {
    const openBtn = document.getElementById("openReview");
    const modal = document.getElementById("id02");
    const closeBtn = modal.querySelector(".close");
    const cancelBtn = modal.querySelector(".cancel-btn");

    // Άνοιγμα
    openBtn.addEventListener("click", (e) => {
        e.preventDefault(); // Εμποδίζει το redirect!
        e.stopPropagation(); // Σταματάει οποιοδήποτε άλλο script να "δει" το κλικ
        modal.style.display = "block";
    });

    // Κλείσιμο
    closeBtn.addEventListener("click", () => modal.style.display = "none");
    cancelBtn.addEventListener("click", () => modal.style.display = "none");
});