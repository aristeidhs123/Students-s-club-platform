import { ClubsAPI } from "../connection_f_b/api.js";

// ==========================================================================
// 1. ΦΟΡΤΩΣΗ ΤΩΝ CLUBS (Από το Backend)
// ==========================================================================
async function loadClubs() {
  try {
    const result = await ClubsAPI.getAll();
    const clubs = result.data || [];

    const grid = document.getElementById("clubs-list");
    if (!grid) return;
    grid.innerHTML = "";

    clubs.forEach(club => {
      const card = document.createElement("div");
      card.className = "card card-blue";

      card.innerHTML = `
        <div class="card-top gradient-1"></div>
        <div class="card-content">
          <h3>${club.title}</h3>
          <p>${club.description}</p>

          <div class="tags">
            <span>Status: ${club.status}</span>
            <span>Manager: User #${club.manager_id}</span>
          </div>

          <button class="card-btn" data-id="${club.club_id}">
            View Club
          </button>

          <button class="secondary-btn join-btn" data-id="${club.club_id}">
            Join Club
          </button>
        </div>
      `;

      grid.appendChild(card);
    });

    attachJoinEvents();

  } catch (error) {
    console.error(error);
    const grid = document.getElementById("clubs-list");
    if (grid) {
      grid.innerHTML = "<p>Δεν ήταν δυνατή η φόρτωση των συλλόγων.</p>";
    }
  }
}

function attachJoinEvents() {
  document.querySelectorAll(".join-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      const clubId = btn.dataset.id;
      await ClubsAPI.join(clubId);
      alert("Αίτηση συμμετοχής στάλθηκε!");
    });
  });
}

// ==========================================================================
// 2. ΛΕΙΤΟΥΡΓΙΑ MODALS (Login & Δημιουργία Club)
// ==========================================================================
function setupAllMyOldModals() {
  
  // --- ΦΟΡΜΑ 1: LOGIN (id01) ---
  const modalLogin = document.getElementById("id01");
  const openLoginBtn = document.getElementById("openLogin");
  if (openLoginBtn && modalLogin) {
    openLoginBtn.addEventListener("click", () => {
      modalLogin.style.display = "block";
    });
  }

  // --- ΦΟΡΜΑ 4: ΔΗΜΙΟΥΡΓΙΑ CLUB (id04) ---
  const modalCreateClub = document.getElementById("id04");
  const openCreateClubBtn = document.getElementById("openCreateClub");
  if (openCreateClubBtn && modalCreateClub) {
    openCreateClubBtn.addEventListener("click", () => {
      modalCreateClub.style.display = "block";
    });
  }

  // --- ΚΛΕΙΣΙΜΟ ΓΙΑ ΟΛΑ ΤΑ MODALS (Κλικ έξω από το καθένα) ---
  window.addEventListener("click", (event) => {
    if (modalLogin && event.target === modalLogin) {
      modalLogin.style.display = "none";
    }
    if (modalCreateClub && event.target === modalCreateClub) {
      modalCreateClub.style.display = "none";
    }
  });
} 

// ==========================================================================
// 3. ΑΥΤΟΜΑΤΗ ΕΚΚΙΝΗΣΗ ΜΟΛΙΣ ΦΟΡΤΩΣΕΙ Η ΣΕΛΙΔΑ
// ==========================================================================
document.addEventListener("DOMContentLoaded", () => {
    loadClubs();             
    setupAllMyOldModals();   
});