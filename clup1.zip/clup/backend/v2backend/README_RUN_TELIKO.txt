ΤΛ ΤΕΛΙΚΟ - Οδηγίες εκτέλεσης

1) Πήγαινε στον backend φάκελο:
cd ~/PROJECTS/ΤΕΧΝΟΛΟΓΙΑ\ ΛΟΓΙΣΜΙΚΟΥ/τλ_τελικο/backend/v2backend

2) Εγκατάσταση packages:
npm install

3) Αν δεν έχεις .env, φτιάξε ένα αρχείο .env μέσα στο backend/v2backend:
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=το_password_σου
DB_NAME=clup
PORT=3000

4) Τρέξιμο:
npm start

5) Άνοιγμα εφαρμογής:
http://localhost:3000

Σημαντικό:
- Δεν χρησιμοποιούνται mock δεδομένα στο frontend.
- Οι λίστες συλλόγων, εκδηλώσεων και ανακοινώσεων γεμίζουν από τα /api endpoints.
- Αν η βάση δεν έχει δεδομένα, θα εμφανιστεί μήνυμα ότι δεν υπάρχουν δεδομένα.
- Αν θες δοκιμαστικά δεδομένα, τρέξε στη MySQL πρώτα το clup_database.txt και μετά το inserts_dummies.sql.
