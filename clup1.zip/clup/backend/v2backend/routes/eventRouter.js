import express from 'express';
import { managerClubs, createEvent, showjoinevent, newreservation, showpendingres, acceptRes, rejectRes, showAllEvents, showEventById, showPublicEvents, showPrivateEvents } from '../controllers/eventController.js';

const eventrouter = express.Router();

eventrouter.post('/showmanagerid', managerClubs);
eventrouter.get('/showmanagerevents', managerClubs);
eventrouter.post('/newevent', createEvent);
eventrouter.get('/showusersevents', showjoinevent);
eventrouter.post('/joinevent', newreservation);
eventrouter.get('/showpendingreservation', showpendingres);
eventrouter.post('/acceptreservation', acceptRes);
eventrouter.post('/rejectreservation', rejectRes);
eventrouter.get('/showallevents', showAllEvents);
eventrouter.get('/events/:eventId', showEventById);
eventrouter.get('/showpublicevents', showPublicEvents);
eventrouter.get('/showprivateevents', showPrivateEvents);

export default eventrouter;
