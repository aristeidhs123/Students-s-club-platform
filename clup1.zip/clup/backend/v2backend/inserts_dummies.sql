USE clup;

INSERT INTO user (name, lastname, email, password, role)
VALUES
('Admin', 'User', 'admin@example.com', '123456', 'admin'),
('Tania', 'TestUser', 'testuser@example.com', '123456', 'user'),
('Maria', 'Manager', 'manager@example.com', '123456', 'manager');

INSERT INTO club (title, description, manager_id, status)
VALUES
('Tech Club', 'Σύλλογος τεχνολογίας με δράσεις, workshops και hackathons.', 3, 'approved'),
('Music Society', 'Σύλλογος μουσικής για πρόβες και συναυλίες.', 3, 'approved'),
('Photography Club', 'Ομάδα φοιτητών για φωτογραφία και δημιουργικές δράσεις.', 3, 'pending');

INSERT INTO membership (userid, clubid, membership_role, membership_status)
VALUES
(2, 1, 'user', 'approved'),
(2, 2, 'user', 'pending'),
(3, 1, 'manager', 'approved');

INSERT INTO event
(ev_clubid, ev_title, ev_description, ev_role, ev_seats, ev_location, ev_gplatos, ev_gmikos, ev_starttime, ev_endtime, ev_status)
VALUES
(1, 'Hackathon Φοιτητών', 'Διαγωνισμός προγραμματισμού από το Tech Club.', 'public', 50, 'Πάτρα', 38.246242, 21.735084, '2026-06-10 10:00:00', '2026-06-10 18:00:00', 'upcoming'),
(2, 'Music Night', 'Live βραδιά με φοιτητικά συγκροτήματα.', 'public', 120, 'Αμφιθέατρο', 38.246242, 21.735084, '2026-06-15 20:00:00', '2026-06-15 23:00:00', 'upcoming'),
(1, 'Completed Workshop', 'Ολοκληρωμένο workshop για δοκιμή αξιολόγησης.', 'public', 30, 'Αίθουσα Α1', 38.246242, 21.735084, '2026-01-10 18:00:00', '2026-01-10 20:00:00', 'completed');

INSERT INTO reservation (res_evid, res_userid, res_status, res_apprearedatevent)
VALUES
(3, 2, 'approved', TRUE);

INSERT INTO review_EVENT (r_eventid, r_userid, r_review, r_descr)
VALUES
(3, 2, 5, 'Πολύ καλή οργάνωση και χρήσιμο περιεχόμενο.');

INSERT INTO public_announcements (publ_ann_managerid, publ_ann_descr, publ_ann_title)
VALUES
(3, 'Συνάντηση μελών την Παρασκευή στις 18:00.', 'New Meeting'),
(3, 'Άνοιξαν οι εγγραφές για το επόμενο workshop.', 'Workshop Registrations');

INSERT INTO login_activity (user_id, is_active_code)
VALUES
(1, TRUE),
(2, TRUE),
(3, TRUE);
