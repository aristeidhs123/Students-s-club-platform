import mysql from "mysql2/promise";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Φορτώνει σίγουρα το .env από backend/v2backend/.env
dotenv.config({
    path: path.resolve(__dirname, "../.env")
});

// Εναλλακτικά, αν κάποιος το έχει βάλει στο backend/.env
dotenv.config({
    path: path.resolve(__dirname, "../../.env")
});

console.log("DB CONFIG:");
console.log("DB_HOST:", process.env.DB_HOST);
console.log("DB_USER:", process.env.DB_USER);
console.log("DB_NAME:", process.env.DB_NAME);
console.log("DB_PASSWORD exists:", process.env.DB_PASSWORD ? "YES" : "NO");

const db = mysql.createPool({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    database: process.env.DB_NAME || "clup",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

export default db;