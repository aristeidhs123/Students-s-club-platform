import {
    getCurrentUser,
    clearCurrentUser
} from "../connection_f_b/api.js";

const user = getCurrentUser();
const currentPage = location.pathname.split("/").pop() || "login.html";

const publicPages = ["login.html"];

if (!user && !publicPages.includes(currentPage)) {
    window.location.href = "login.html";
}

if (user) {
    buildNavbar(user);
    protectPage(user);
    showRoleMessage(user);
}

function buildNavbar(user) {
    const nav = document.querySelector(".nav-links");

    if (!nav) return;

    const role = user.role || "user";

    const links = [
        { href: "home.html", text: "Home" },
        { href: "clubs.html", text: "Clubs" },
        { href: "events.html", text: "Events" },
        { href: "announcements.html", text: "Announcements" },
        { href: "reviews.html", text: "Reviews" },
        { href: "profile.html", text: "Profile" }
    ];

    if (role === "manager" || role === "admin") {
        links.push({ href: "create_event.html", text: "Create Event" });
        links.push({ href: "schedule.html", text: "Schedule" });
    }

    if (role === "manager") {
        links.push({ href: "admin.html", text: "Club Panel" });
    }

    if (role === "admin") {
        links.push({ href: "admin.html", text: "Admin" });
    }

    nav.innerHTML = "";

    links.forEach(function (link) {
        const a = document.createElement("a");
        a.href = link.href;
        a.textContent = link.text;
        nav.appendChild(a);
    });

    const userBadge = document.createElement("span");
    userBadge.className = "user-badge";
    userBadge.textContent = (user.name || user.email) + " · " + role;
    nav.appendChild(userBadge);

    const logoutBtn = document.createElement("button");
    logoutBtn.className = "logout-btn";
    logoutBtn.type = "button";
    logoutBtn.textContent = "Logout";

    logoutBtn.addEventListener("click", function () {
        clearCurrentUser();
        window.location.href = "login.html";
    });

    nav.appendChild(logoutBtn);
}

function protectPage(user) {
    const role = user.role || "user";

    const adminOnlyPages = [
        "admin.html"
    ];

    const managerPages = [
        "create_event.html",
        "schedule.html"
    ];

    if (adminOnlyPages.includes(currentPage) && role !== "admin" && role !== "manager") {
        window.location.href = "home.html";
        return;
    }

    if (managerPages.includes(currentPage) && role !== "manager" && role !== "admin") {
        window.location.href = "home.html";
    }
}

function showRoleMessage(user) {
    const target = document.querySelector("[data-role-message]");

    if (!target) return;

    const role = user.role || "user";

    if (role === "admin") {
        target.textContent = "Συνδέθηκες ως admin. Έχεις πρόσβαση σε εποπτεία και στατιστικά εφαρμογής.";
    } else if (role === "manager") {
        target.textContent = "Συνδέθηκες ως διαχειριστής συλλόγου. Έχεις πρόσβαση σε λειτουργίες ομάδας.";
    } else {
        target.textContent = "Συνδέθηκες ως φοιτητής. Μπορείς να δεις συλλόγους, εκδηλώσεις και αξιολογήσεις.";
    }
}