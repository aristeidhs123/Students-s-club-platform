import { EventsAPI } from "../connection_f_b/api.js";

async function loadEvents() {
    const grid = document.getElementById("events-list");
    const pastGrid = document.getElementById("past-events-list");
    if (grid) grid.innerHTML = "<p>Φόρτωση εκδηλώσεων...</p>";
    if (pastGrid) pastGrid.innerHTML = "";

    try {
        const result = await EventsAPI.getAll();
        const events = result.data || [];
        if (grid) grid.innerHTML = "";
        if (!events.length && grid) {
            grid.innerHTML = "<p>Δεν υπάρχουν εκδηλώσεις στη βάση.</p>";
            return;
        }

        events.forEach(ev => {
            const card = document.createElement("div");
            card.className = "card card-purple";
            card.innerHTML = `
                <div class="card-top gradient-2"></div>
                <div class="card-content">
                    <h3>${ev.ev_title}</h3>
                    <p>${ev.ev_description || ""}</p>
                    <p><strong>Location:</strong> ${ev.ev_location || "-"}</p>
                    <p><strong>Seats:</strong> ${ev.ev_seats ?? "-"}</p>
                    <p><strong>Starts:</strong> ${ev.ev_starttime || "-"}</p>
                    <button class="card-btn" onclick="window.location.href='event_details.html?id=${ev.event_id}'">View Event</button>
                    <button class="secondary-btn participate-btn" data-id="${ev.event_id}" style="margin-top:10px;">Participate</button>
                </div>`;
            grid.appendChild(card);
        });

        document.querySelectorAll(".participate-btn").forEach(btn => {
            btn.addEventListener("click", async () => {
                await EventsAPI.participate(btn.dataset.id);
                alert("Η αίτηση συμμετοχής στάλθηκε!");
            });
        });
    } catch (error) {
        if (grid) grid.innerHTML = "<p>Δεν ήταν δυνατή η φόρτωση των εκδηλώσεων από το backend.</p>";
    }
}

document.addEventListener("DOMContentLoaded", loadEvents);
