import { AnnouncementsAPI } from "../connection_f_b/api.js";

async function loadAnnouncements() {
    const list = document.getElementById("announcements-list");
    if (!list) return;
    list.innerHTML = "<p>Φόρτωση ανακοινώσεων...</p>";

    try {
        const result = await AnnouncementsAPI.getAll();
        const announcements = result.data || [];
        list.innerHTML = "";

        if (!announcements.length) {
            list.innerHTML = "<p>Δεν υπάρχουν ανακοινώσεις στη βάση.</p>";
            return;
        }

        announcements.forEach(a => {
            const item = document.createElement("div");
            item.className = "card card-cyan";
            item.innerHTML = `
                <div class="card-top gradient-3"></div>
                <div class="card-content">
                    <h3>${a.ann_title}</h3>
                    <p>${a.ann_descr || ""}</p>
                    <p><strong>Date:</strong> ${a.ann_date || "-"}</p>
                    <p><strong>Visibility:</strong> Public</p>
                </div>`;
            list.appendChild(item);
        });
    } catch (error) {
        list.innerHTML = "<p>Σφάλμα φόρτωσης ανακοινώσεων από το backend.</p>";
    }
}

document.addEventListener("DOMContentLoaded", loadAnnouncements);
