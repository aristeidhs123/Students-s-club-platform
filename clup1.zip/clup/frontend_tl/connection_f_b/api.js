const API_BASE = "/api";

const USER_KEY = "clup_current_user";

export function setCurrentUser(user) {
    const cleanUser = {
        user_id: user.user_id || user.id,
        name: user.name || "",
        lastname: user.lastname || "",
        email: user.email || "",
        role: user.role || "user"
    };

    localStorage.setItem(USER_KEY, JSON.stringify(cleanUser));
}

export function getCurrentUser() {
    try {
        return JSON.parse(localStorage.getItem(USER_KEY));
    } catch (error) {
        return null;
    }
}

export function clearCurrentUser() {
    localStorage.removeItem(USER_KEY);
}

export function getCurrentUserId() {
    return getCurrentUser()?.user_id || 1;
}

export function getCurrentUserRole() {
    return getCurrentUser()?.role || "guest";
}

async function apiRequest(endpoint, method = "GET", body = null) {
    const options = {
        method: method,
        headers: {
            "Content-Type": "application/json"
        }
    };

    if (body !== null) {
        options.body = JSON.stringify(body);
    }

    const response = await fetch(API_BASE + endpoint, options);

    let result = null;

    try {
        result = await response.json();
    } catch (error) {
        result = null;
    }

    if (!response.ok) {
        throw new Error(result?.error || result?.message || "API Error");
    }

    return result;
}

export const AuthAPI = {
    login: function ({ email, password }) {
        return apiRequest("/login", "POST", {
            email: email,
            useremail: email,
            password: password
        });
    },

    signup: function ({ name, lastname, email, password }) {
        return apiRequest("/newuser", "POST", {
            name: name,
            lastname: lastname,
            email: email,
            password: password,
            role: "user"
        });
    }
};

export const ClubsAPI = {
    getAll: function () {
        return apiRequest("/showclubs");
    },

    getById: function (clubId) {
        return apiRequest("/clubs/" + clubId);
    },

    create: function (data) {
        return apiRequest("/newclub", "POST", data);
    },

    getPending: function () {
        return apiRequest("/pendingForms");
    },

    approve: function (club_id, manager_id) {
        return apiRequest("/acceptnewclub", "POST", {
            club_id: club_id,
            manager_id: manager_id
        });
    },

    reject: function (club_id) {
        return apiRequest("/rejectnewclub", "POST", {
            club_id: club_id
        });
    },

    join: function (clubid, userid = getCurrentUserId()) {
        return apiRequest("/joinclub", "POST", {
            clubid: clubid,
            userid: userid
        });
    }
};

export const MembershipAPI = {
    join: function (clubid, userid = getCurrentUserId()) {
        return apiRequest("/joinclub", "POST", {
            clubid: clubid,
            userid: userid
        });
    },

    getPending: function () {
        return apiRequest("/pendingmemberships");
    },

    approve: function (membership_id) {
        return apiRequest("/acceptnewmember", "POST", {
            membership_id: membership_id
        });
    },

    reject: function (membership_id) {
        return apiRequest("/rejectnewmember", "POST", {
            membership_id: membership_id
        });
    },

    getMembers: function () {
        return apiRequest("/showmembers");
    }
};

export const EventsAPI = {
    getAll: function () {
        return apiRequest("/showallevents");
    },

    getById: function (eventId) {
        return apiRequest("/events/" + eventId);
    },

    create: function (data) {
        return apiRequest("/newevent", "POST", data);
    },

    participate: function (eventid, userid = getCurrentUserId()) {
        return apiRequest("/joinevent", "POST", {
            eventid: eventid,
            userid: userid
        });
    },

    getCompletedForReview: function (userid = getCurrentUserId()) {
        return apiRequest("/event-reviews/completed/" + userid);
    }
};

export const AnnouncementsAPI = {
    getAll: function () {
        return apiRequest("/showpublicannouncments");
    },

    createPrivate: function (data) {
        return apiRequest("/newprivateannouncments", "POST", data);
    },

    createPublic: function (data) {
        return apiRequest("/newpublicannouncment", "POST", data);
    }
};

export const ReviewsAPI = {
    getPublic: function (eventId = 1) {
        return apiRequest("/event-reviews/public/" + eventId);
    },

    create: function (eventId, data) {
        return apiRequest("/event-reviews/" + eventId, "POST", data);
    }
};

export const ProfileAPI = {
    get: function (id = getCurrentUserId()) {
        return apiRequest("/profile/" + id);
    },

    updateBio: function (id, bio) {
        return apiRequest("/profile/" + id + "/bio", "PATCH", {
            bio: bio
        });
    },

    updateInterests: function (id, interests) {
        return apiRequest("/profile/" + id + "/interests", "PATCH", {
            interests: interests
        });
    },

    getUserClubs: function (id = getCurrentUserId()) {
        return apiRequest("/profile/" + id + "/clubs");
    },

    leaveClub: function (userId, clubId) {
        return apiRequest("/profile/" + userId + "/clubs/" + clubId, "DELETE");
    }
};

export const ChatbotAPI = {
    ask: function (data) {
        return apiRequest("/chatbot/ask", "POST", data);
    },

    contactAdmin: function (data) {
        return apiRequest("/chatbot/contact-admin", "POST", data);
    },

    history: function (userId = getCurrentUserId()) {
        return apiRequest("/chatbot/user/" + userId);
    },

    unread: function () {
        return apiRequest("/chatbot/admin/unread");
    },

    answer: function (contactId, data) {
        return apiRequest("/chatbot/admin/answer/" + contactId, "PATCH", data);
    }
};

export const ScheduleAPI = {
    getByClub: function () {
        return Promise.resolve({
            data: {
                title: "Χρονοδιάγραμμα ομάδας"
            }
        });
    }
};

export const StatisticsAPI = {
    appOptions: function () {
        return apiRequest("/app-statistics/options");
    },

    chatbotUsage: function () {
        return apiRequest("/app-statistics/chatbot-usage");
    },

    appUsage: function () {
        return apiRequest("/app-statistics/app-usage");
    },

    clubOptions: function () {
        return apiRequest("/club-statistics/options");
    },

    clubEvents: function (clubId) {
        return apiRequest("/club-statistics/events/" + clubId);
    },

    memberParticipation: function (clubId) {
        return apiRequest("/club-statistics/member-participation/" + clubId);
    },

    recordVisit: function (clubId, data) {
        return apiRequest("/club-statistics/visit/" + clubId, "POST", data);
    }
};

window.ClubsAPI = ClubsAPI;
window.MembershipAPI = MembershipAPI;
window.EventsAPI = EventsAPI;
window.AnnouncementsAPI = AnnouncementsAPI;
window.ReviewsAPI = ReviewsAPI;
window.ProfileAPI = ProfileAPI;
window.AuthAPI = AuthAPI;
window.ChatbotAPI = ChatbotAPI;
window.ScheduleAPI = ScheduleAPI;
window.StatisticsAPI = StatisticsAPI;