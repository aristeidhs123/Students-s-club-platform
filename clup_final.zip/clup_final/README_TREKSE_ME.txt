CLUP_TELOS - ΟΔΗΓΙΕΣ ΤΡΕΞΙΜΑΤΟΣ

1) Πήγαινε στον backend φάκελο:

cd ~/PROJECTS/ΤΕΧΝΟΛΟΓΙΑ\ ΛΟΓΙΣΜΙΚΟΥ/clup_telos/backend/v2backend

2) Έλεγξε το .env:

DB_HOST=localhost
DB_USER=root
DB_PASSWORD="RootPass#2025"
DB_NAME=clup
PORT=3000

3) Αν η MySQL root δέχεται το RootPass#2025, φόρτωσε καθαρή βάση:

mysql -u root -p

και μέσα στη MySQL:

DROP DATABASE IF EXISTS clup;
CREATE DATABASE clup CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE clup;
source clup_database.txt;
source inserts_dummies.sql;
exit;

4) Τρέξε την εφαρμογή:

npm install
npm start

5) Άνοιξε:

http://localhost:3000

Λογαριασμοί test:

admin@example.com / 123456
manager@example.com / 123456
testuser@example.com / 123456
privileged@example.com / 123456

ΣΗΜΕΙΩΣΗ ΓΙΑ MYSQL ROOT PASSWORD
Αν το command mysql -u root -p με RootPass#2025 δεν μπαίνει, τότε δεν φταίει το project. Χρειάζεται reset του MySQL root password στο σύστημά σου. Το project κρατάει DB_USER=root όπως ζήτησες.
