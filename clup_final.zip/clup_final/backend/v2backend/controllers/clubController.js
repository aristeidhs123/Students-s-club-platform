import { club, rejectclub as dbRejectClub, acceptclub as dbAcceptClub, showclubs as dbShowClubs, show_pendingClubs, turntomanager, searchclubs } from '../models/mydatabase.js';

export const createNewclub = async (req, res) => {
    try {
        const data = req.body;
        await club(data.title, data.description, data.managerid || data.manager_id || 1);
        res.status(201).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η δημιουργία συλλόγου." });
    }
};

export const rejectClub = async (req, res) => {
    try {
        await dbRejectClub(req.body.club_id || req.body.clubid || req.body.id);
        res.status(200).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η απόρριψη συλλόγου." });
    }
};

export const acceptClub = async (req, res) => {
    try {
        await dbAcceptClub(req.body.club_id || req.body.clubid || req.body.id);
        if (req.body.manager_id) await turntomanager(req.body.manager_id);
        res.status(200).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η έγκριση συλλόγου." });
    }
};

export const showallClub = async (req, res) => {
    try {
        const approvedclubs = await dbShowClubs();
        res.status(200).json({ data: approvedclubs, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση συλλόγων." });
    }
};

export const showClubById = async (req, res) => {
    try {
        const oneClub = await searchclubs(req.params.clubId);
        if (!oneClub) return res.status(404).json({ error: "Ο σύλλογος δεν βρέθηκε." });
        res.status(200).json({ data: oneClub, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση συλλόγου." });
    }
};

export const showpendingClub = async (req, res) => {
    try {
        const pendingclubs = await show_pendingClubs();
        res.status(200).json({ data: pendingclubs, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση εκκρεμών συλλόγων." });
    }
};

// aliases για να μη σπάσουν παλιά imports/routes
export const rejectclub = rejectClub;
export const acceptclub = acceptClub;
export const showclubs = showallClub;
