import { returnusrole, newevent, showallevents, pastevents,showclubevents, showpublicevents, showprivateevents, searchmanagerclubs, checkeventsloc, searchmemberships, reservationevent, showpendingreservation, acceptreservation, rejectreservation } from '../models/mydatabase.js';

export const managerClubs = async (req, res) => {
    try {
        const managerid = req.body.managerid || req.body.user_id || req.body.userid || 1;
        const role = await returnusrole(managerid);
        if (role !== 'manager' && role !== 'admin') return res.status(403).json({ error: "Δεν έχεις δικαιώματα διαχειριστή." });
        const managersclubs = await searchmanagerclubs(managerid);
        res.status(200).json({ data: managersclubs, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση συλλόγων manager." });
    }
};

export const createEvent = async (req, res) => {
    try {
        const event = req.body;
        const busy = await checkeventsloc(event.location, event.starttime, event.endtime);
        if (busy) return res.status(409).json({ error: "Ο χώρος χρησιμοποιείται ήδη σε αυτή την ώρα." });

        await newevent(
            event.evclubid || event.clubid || event.ev_clubid || 1,
            event.title || event.ev_title,
            event.description || event.ev_description,
            event.role || event.ev_role || 'public',
            event.seats || event.ev_seats || 0,
            event.location || event.ev_location,
            event.gplatos || event.ev_gplatos || 38.246242,
            event.gmikos || event.ev_gmikos || 21.735084,
            event.starttime || event.ev_starttime,
            event.endtime || event.ev_endtime
        );
        res.status(201).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η δημιουργία εκδήλωσης." });
    }
};

export const showjoinevent = async (req, res) => {
    try {
        const userid = req.query.userid || req.body.userid || 1;
        const usersclubs = await searchmemberships(userid);
        const usersevent = await showclubevents(usersclubs);
        res.status(200).json({ data: usersevent, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση εκδηλώσεων χρήστη." });
    }
};

export const newreservation = async (req, res) => {
    try {
        await reservationevent(req.body.eventid || req.body.event_id, req.body.userid || req.body.user_id || 1);
        res.status(201).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η δήλωση συμμετοχής." });
    }
};

export const showpendingres = async (req, res) => {
    try {
        const pendingres = await showpendingreservation();
        res.status(200).json({ data: pendingres, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση εκκρεμών κρατήσεων." });
    }
};

export const acceptRes = async (req, res) => {
    try {
        await acceptreservation(req.body.res_id || req.body.resid || req.body.id);
        res.status(200).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η έγκριση κράτησης." });
    }
};

export const rejectRes = async (req, res) => {
    try {
        await rejectreservation(req.body.res_id || req.body.resid || req.body.id);
        res.status(200).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η απόρριψη κράτησης." });
    }
};

export const showAllEvents = async (req, res) => {
    try {
        const allevents = await showallevents();
        res.status(200).json({ data: allevents, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση εκδηλώσεων." });
    }
};

export const showPastEvents = async (req, res) => {
    try {
        const pstevents = await pastevents();
        res.status(200).json({ data: pstevents, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση παλαιών εκδηλώσεων." });
    }
};

export const showEventById = async (req, res) => {
    try {
        const allevents = await showallevents();
        const event = allevents.find(e => String(e.event_id) === String(req.params.eventId));
        if (!event) return res.status(404).json({ error: "Η εκδήλωση δεν βρέθηκε." });
        res.status(200).json({ data: event, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση εκδήλωσης." });
    }
};

export const showPublicEvents = async (req, res) => {
    try {
        const pubevents = await showpublicevents();
        res.status(200).json({ data: pubevents, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση δημόσιων εκδηλώσεων." });
    }
};

export const showPrivateEvents = async (req, res) => {
    try {
        const prevents = await showprivateevents();
        res.status(200).json({ data: prevents, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση ιδιωτικών εκδηλώσεων." });
    }
};
