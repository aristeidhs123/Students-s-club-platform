import { newmembership as dbNewMembership, show_pendingMemberships, apprmember, rejmember, show_approvedMemberships, searchmemberships } from '../models/mydatabase.js';

export const joinclub = async (req, res) => {
    try {
        await dbNewMembership(req.body.userid || req.body.user_id || 1, req.body.clubid || req.body.club_id);
        res.status(201).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η αίτηση συμμετοχής." });
    }
};

export const pendingMemberships = async (req, res) => {
    try {
        const pendingmemberships = await show_pendingMemberships();
        res.status(200).json({ data: pendingmemberships, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση αιτήσεων συμμετοχής." });
    }
};

export const acceptMember = async (req, res) => {
    try {
        await apprmember(req.body.membership_id || req.body.memberid || req.body.id);
        res.status(200).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η έγκριση μέλους." });
    }
};

export const rejectMember = async (req, res) => {
    try {
        await rejmember(req.body.membership_id || req.body.memberid || req.body.id);
        res.status(200).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η απόρριψη μέλους." });
    }
};

export const showMembers = async (req, res) => {
    try {
        const members = await show_approvedMemberships();
        res.status(200).json({ data: members, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση μελών." });
    }
};

export const usmemberships = async (req, res) => {
    try {
        const userid = req.body.userid || req.query.userid || req.body.user_id || 1;
        const userscl = await searchmemberships(userid);
        res.status(200).json({ data: userscl, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση συμμετοχών χρήστη." });
    }
};
