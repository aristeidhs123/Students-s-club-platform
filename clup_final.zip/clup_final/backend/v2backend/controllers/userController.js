import { createuser, searchuser, showprofile } from '../models/mydatabase.js';
import bcrypt from 'bcryptjs';

export const createNewuser = async (req, res) => {
    try {
        const data = req.body;
        const cryptopassword = await bcrypt.hash(data.password, 10);
        await createuser(data.name, data.lastname, data.email, cryptopassword);
        res.status(201).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η δημιουργία χρήστη." });
    }
};

export const login = async (req, res) => {
    try {
        const user = req.body;
        const databaseuser = await searchuser(user.email || user.useremail);
        if (!databaseuser) return res.status(401).json({ error: "Λάθος email." });

        const plainPassword = user.password || user.userpassword;
        let ok = false;

        if (databaseuser.password?.startsWith('$2')) {
            ok = await bcrypt.compare(plainPassword, databaseuser.password);
        } else {
            ok = plainPassword === databaseuser.password;
        }

        if (!ok) return res.status(401).json({ error: "Λάθος password." });

        const { password, ...safeUser } = databaseuser;
        res.status(200).json({ data: safeUser, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η σύνδεση." });
    }
};

export const returnUser = async (req, res) => {
    try {
        const user = await showprofile(req.query.user_id || 1);
        if (!user) return res.status(404).json({ error: "Ο χρήστης δεν βρέθηκε." });
        const { password, ...safeUser } = user;
        res.status(200).json({ data: safeUser, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση χρήστη." });
    }
};
