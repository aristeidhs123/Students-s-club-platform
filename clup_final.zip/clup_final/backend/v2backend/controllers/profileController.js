import db from "../config/db.js";

export async function getProfile(req, res) {
    try {
        const { userId } = req.params;

        const [users] = await db.query(
            `
            SELECT 
                user_id,
                name,
                lastname,
                email,
                role,
                profil_img,
                user_bio,
                user_interests
            FROM user
            WHERE user_id = ?
            `,
            [userId]
        );

        if (users.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Ο χρήστης δεν βρέθηκε."
            });
        }

        res.json({
            success: true,
            data: users[0],
            profile: users[0]
        });

    } catch (error) {
        console.error("Get profile error:", error);

        res.status(500).json({
            success: false,
            message: "Σφάλμα κατά την ανάκτηση προφίλ."
        });
    }
}

export async function checkUsernameAvailability(req, res) {
    res.json({
        success: true,
        available: true,
        message: "Το αρχικό σχήμα της βάσης δεν χρησιμοποιεί ξεχωριστό username."
    });
}

export async function updateUsername(req, res) {
    res.json({
        success: true,
        message: "Το αρχικό σχήμα της βάσης δεν έχει username, οπότε δεν έγινε αλλαγή."
    });
}

export async function updateProfileImage(req, res) {
    try {
        const { userId } = req.params;
        const { profil_img } = req.body;

        await db.query(
            `
            UPDATE user
            SET profil_img = ?
            WHERE user_id = ?
            `,
            [profil_img || null, userId]
        );

        res.json({
            success: true,
            message: "Η εικόνα προφίλ ενημερώθηκε."
        });

    } catch (error) {
        console.error("Update profile image error:", error);

        res.status(500).json({
            success: false,
            message: "Σφάλμα κατά την ενημέρωση εικόνας προφίλ."
        });
    }
}

export async function updateInterests(req, res) {
    try {
        const { userId } = req.params;
        const { interests, user_interests } = req.body;
        const finalInterests = user_interests || interests || "";

        await db.query(
            `
            UPDATE user
            SET user_interests = ?
            WHERE user_id = ?
            `,
            [finalInterests, userId]
        );

        res.json({
            success: true,
            message: "Τα ενδιαφέροντα ενημερώθηκαν."
        });

    } catch (error) {
        console.error("Update interests error:", error);

        res.status(500).json({
            success: false,
            message: "Σφάλμα κατά την ενημέρωση ενδιαφερόντων."
        });
    }
}

export async function updateBio(req, res) {
    try {
        const { userId } = req.params;
        const { bio, user_bio } = req.body;
        const finalBio = user_bio || bio || "";

        await db.query(
            `
            UPDATE user
            SET user_bio = ?
            WHERE user_id = ?
            `,
            [finalBio, userId]
        );

        res.json({
            success: true,
            message: "Το bio ενημερώθηκε."
        });

    } catch (error) {
        console.error("Update bio error:", error);

        res.status(500).json({
            success: false,
            message: "Σφάλμα κατά την ενημέρωση bio."
        });
    }
}

export async function getUserClubs(req, res) {
    try {
        const { userId } = req.params;

        const [clubs] = await db.query(
            `
            SELECT 
                c.club_id,
                c.title,
                c.description,
                c.manager_id,
                c.status,
                c.creationdate,
                m.membership_role,
                m.membership_status
            FROM membership m
            JOIN club c ON c.club_id = m.clubid
            WHERE m.userid = ?
            AND m.membership_status = 'approved'
            `,
            [userId]
        );

        res.json({
            success: true,
            data: clubs
        });

    } catch (error) {
        console.error("Get user clubs error:", error);

        res.status(500).json({
            success: false,
            message: "Σφάλμα κατά την ανάκτηση συλλόγων χρήστη."
        });
    }
}

export async function leaveClub(req, res) {
    try {
        const { userId, clubId } = req.params;

        await db.query(
            `
            DELETE FROM membership
            WHERE userid = ?
            AND clubid = ?
            `,
            [userId, clubId]
        );

        res.json({
            success: true,
            message: "Ο χρήστης αφαιρέθηκε από τον σύλλογο."
        });

    } catch (error) {
        console.error("Leave club error:", error);

        res.status(500).json({
            success: false,
            message: "Σφάλμα κατά την αποχώρηση από σύλλογο."
        });
    }
}

export async function updateProfile(req, res) {
    try {
        const { userId } = req.params;
        const {
            name,
            lastname,
            profil_img,
            user_bio,
            bio,
            user_interests,
            interests
        } = req.body;

        await db.query(
            `
            UPDATE user
            SET
                name = COALESCE(?, name),
                lastname = COALESCE(?, lastname),
                profil_img = ?,
                user_bio = ?,
                user_interests = ?
            WHERE user_id = ?
            `,
            [
                name || null,
                lastname || null,
                profil_img || null,
                user_bio || bio || "",
                user_interests || interests || "",
                userId
            ]
        );

        const [users] = await db.query(
            `
            SELECT user_id, name, lastname, email, role, profil_img, user_bio, user_interests
            FROM user
            WHERE user_id = ?
            `,
            [userId]
        );

        res.json({
            success: true,
            message: "Το προφίλ ενημερώθηκε.",
            data: users[0]
        });
    } catch (error) {
        console.error("Update profile error:", error);
        res.status(500).json({
            success: false,
            message: "Σφάλμα κατά την ενημέρωση προφίλ."
        });
    }
}
