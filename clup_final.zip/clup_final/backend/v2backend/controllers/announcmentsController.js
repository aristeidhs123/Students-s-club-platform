import { newprannouncements, newpublannouncements, showpublicannnouncements, showprclubannouncements, returnusrole } from '../models/mydatabase.js';

export const newprivateannouncement = async (req, res) => {
    try {
        const data = req.body;
        await newprannouncements(data.clubid || data.club_id, data.userid || data.user_id || 1, data.title || data.ann_title, data.descr || data.description || data.ann_descr);
        res.status(201).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η δημιουργία ιδιωτικής ανακοίνωσης." });
    }
};

export const newpublicannouncment = async (req, res) => {
    try {
        const data = req.body;
        const managerid = data.publ_ann_managerid || data.managerid || data.manager_id || data.userid || data.user_id || 1;
        const role = await returnusrole(managerid);
        if (role !== 'manager' && role !== 'admin') return res.status(403).json({ error: "Δεν έχεις δικαιώματα δημοσίευσης." });
        await newpublannouncements(managerid, data.publ_ann_descr || data.description || data.descr || data.ann_descr, data.publ_ann_title || data.title || data.ann_title);
        res.status(201).json({ message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η δημιουργία δημόσιας ανακοίνωσης." });
    }
};

export const showallpubannounc = async (req, res) => {
    try {
        const announcements = await showpublicannnouncements();
        res.status(200).json({ data: announcements, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση ανακοινώσεων." });
    }
};

export const showprivateclubannounc = async (req, res) => {
    try {
        const announcements = await showprclubannouncements(req.params.clubId);
        res.status(200).json({ data: announcements, message: "success" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Δεν ήταν δυνατή η φόρτωση ιδιωτικών ανακοινώσεων." });
    }
};
