import express from "express";
import cors from "cors";
import path from "path";
import dotenv from "dotenv";
import { fileURLToPath } from "url";

import chatbotRoutes from "./routes/chatbotRoutes.js";
import internalScheduleRoutes from "./routes/internalScheduleRoutes.js";
import internalActivityRoutes from "./routes/internalActivityRoutes.js";
import internalPermissionRoutes from "./routes/internalPermissionRoutes.js";
import eventReviewRoutes from "./routes/eventReviewRoutes.js";
import clubStatisticsRoutes from "./routes/clubStatisticsRoutes.js";
import appStatisticsRoutes from "./routes/appStatisticsRoutes.js";
import profileRoutes from "./routes/profileRoutes.js";
import clubRoutes from "./routes/clubRoutes.js";
import membershipRoutes from "./routes/membershipRoutes.js";
import userRoutes from "./routes/userRoutes.js";
import eventRoutes from "./routes/eventRouter.js";
import announcementRoutes from "./routes/announcmentsRoutes.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.resolve(__dirname, ".env"), override: true });
const app = express();
const PORT = process.env.PORT || 3000;
const frontendPath = path.resolve(__dirname, "../../frontend_tl");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api/chatbot", chatbotRoutes);
app.use("/api/internal-schedules", internalScheduleRoutes);
app.use("/api/internal-activities", internalActivityRoutes);
app.use("/api/internal-permissions", internalPermissionRoutes);
app.use("/api/event-reviews", eventReviewRoutes);
app.use("/api/club-statistics", clubStatisticsRoutes);
app.use("/api/app-statistics", appStatisticsRoutes);
app.use("/api/profile", profileRoutes);
app.use("/api", clubRoutes);
app.use("/api", membershipRoutes);
app.use("/api", userRoutes);
app.use("/api", eventRoutes);
app.use("/api", announcementRoutes);

app.use(express.static(frontendPath));

app.get("/", (req, res) => {
    res.redirect("/pages/login.html");
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
