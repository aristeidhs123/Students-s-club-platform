import express from "express";
import { createInternalSchedule, getSchedulesByClub } from "../controllers/internalScheduleController.js";

const router = express.Router();

router.get("/club/:clubId", getSchedulesByClub);
router.post("/", createInternalSchedule);

export default router;
