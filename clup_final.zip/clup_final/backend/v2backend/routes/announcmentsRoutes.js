import express from 'express';
import { newprivateannouncement, newpublicannouncment, showallpubannounc, showprivateclubannounc } from '../controllers/announcmentsController.js';

const announcmentsrouter = express.Router();

announcmentsrouter.post('/newprivateannouncments', newprivateannouncement);
announcmentsrouter.post('/newpublicannouncment', newpublicannouncment);
announcmentsrouter.get('/showpublicannouncments', showallpubannounc);
announcmentsrouter.get('/clubs/:clubId/privateannouncments', showprivateclubannounc);

export default announcmentsrouter;
