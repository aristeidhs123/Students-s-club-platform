import express from 'express';
import { createNewclub, showpendingClub, showallClub, showClubById, rejectClub, acceptClub } from '../controllers/clubController.js';

const clubrouter = express.Router();

clubrouter.post('/newclub', createNewclub);
clubrouter.get('/showclubs', showallClub);
clubrouter.get('/clubs/:clubId', showClubById);
clubrouter.get('/pendingForms', showpendingClub);
clubrouter.post('/acceptnewclub', acceptClub);
clubrouter.post('/rejectnewclub', rejectClub);

export default clubrouter;
