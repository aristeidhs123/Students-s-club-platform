USE clup;

INSERT INTO user (name, lastname, email, password, role, user_bio, user_interests)
VALUES
('Admin', 'User', 'admin@example.com', '123456', 'admin', 'Γενικός διαχειριστής της πλατφόρμας.', 'Administration, Statistics'),
('Tania', 'TestUser', 'testuser@example.com', '123456', 'user', 'Φοιτήτρια που συμμετέχει σε συλλόγους και εκδηλώσεις.', 'Music, Tech'),
('Maria', 'Manager', 'manager@example.com', '123456', 'manager', 'Διαχειρίστρια συλλόγου για δοκιμές.', 'Events, Management'),
('Nikos', 'Privileged', 'privileged@example.com', '123456', 'manager', 'Προνομιούχο μέλος με πρόσβαση στο χρονοδιάγραμμα.', 'Schedule, Activities');

INSERT INTO club (title, description, manager_id, status)
VALUES
('Tech Club', 'Σύλλογος τεχνολογίας με δράσεις, workshops και hackathons.', 3, 'approved'),
('Music Society', 'Σύλλογος μουσικής για πρόβες και συναυλίες.', 3, 'approved'),
('Photography Club', 'Ομάδα φοιτητών για φωτογραφία και δημιουργικές δράσεις.', 3, 'pending');

INSERT INTO membership (userid, clubid, membership_role, membership_status)
VALUES
(2, 1, 'user', 'approved'),
(2, 2, 'user', 'pending'),
(3, 1, 'manager', 'approved'),
(4, 1, 'manager', 'approved');

INSERT INTO event
(ev_clubid, ev_title, ev_description, ev_role, ev_seats, ev_location, ev_gplatos, ev_gmikos, ev_starttime, ev_endtime, ev_status)
VALUES
(1, 'Hackathon Φοιτητών', 'Διαγωνισμός προγραμματισμού από το Tech Club.', 'public', 50, 'Πάτρα', 38.246242, 21.735084, '2026-06-10 10:00:00', '2026-06-10 18:00:00', 'upcoming'),
(2, 'Music Night', 'Live βραδιά με φοιτητικά συγκροτήματα.', 'public', 120, 'Αμφιθέατρο', 38.246242, 21.735084, '2026-06-15 20:00:00', '2026-06-15 23:00:00', 'upcoming'),
(1, 'Completed Workshop', 'Ολοκληρωμένο workshop για δοκιμή αξιολόγησης.', 'public', 30, 'Αίθουσα Α1', 38.246242, 21.735084, '2026-01-10 18:00:00', '2026-01-10 20:00:00', 'completed');

INSERT INTO reservation (res_evid, res_userid, res_status, res_apprearedatevent)
VALUES
(3, 2, 'approved', TRUE),
(1, 2, 'approved', FALSE);

INSERT INTO review_EVENT (r_eventid, r_userid, r_review, r_descr)
VALUES
(3, 2, 5, 'Πολύ καλή οργάνωση και χρήσιμο περιεχόμενο.');

INSERT INTO announcements (ann_clubid, ann_userid, ann_descr, ann_title)
VALUES
(1, 3, 'Συνάντηση μελών την Παρασκευή στις 18:00.', 'New Meeting'),
(1, 3, 'Άνοιξαν οι εγγραφές για το επόμενο workshop.', 'Workshop Registrations'),
(2, 3, 'Πρόβα μουσικής ομάδας την Τετάρτη.', 'Music Society Update');

INSERT INTO chatbot_messages (user_id, user_problem, bot_answer, needs_admin, conversation_status)
VALUES
(2, 'Δεν μπορώ να δηλώσω συμμετοχή σε εκδήλωση.', 'Έλεγξε αν η εκδήλωση είναι ακόμη ενεργή.', FALSE, 'BOT_ONLY'),
(2, 'Χρειάζομαι βοήθεια από admin.', 'Θέλεις επικοινωνία με admin;', TRUE, 'WAITING_ADMIN');

INSERT INTO contact_admin_messages (user_id, chatbot_message_id, full_name, email, problem, status)
VALUES
(2, 2, 'Tania TestUser', 'testuser@example.com', 'Χρειάζομαι βοήθεια με συμμετοχή σε εκδήλωση.', 'PENDING');

INSERT INTO internal_schedule (club_id, created_by, title, description, start_date, end_date, status)
VALUES
(1, 3, 'Πρόγραμμα Tech Club', 'Εσωτερικό πρόγραμμα δράσεων του Tech Club.', '2026-06-01', '2026-07-01', 'active');

INSERT INTO internal_activity (schedule_id, created_by, title, description, activity_date, start_time, end_time, location, status)
VALUES
(1, 3, 'Weekly Meeting', 'Συζήτηση για projects και επόμενες δράσεις.', '2026-06-05', '18:00:00', '19:30:00', 'Αίθουσα Α1', 'planned');

INSERT INTO activity_permission (club_id, user_id, granted_by, permission_type)
VALUES
(1, 4, 3, 'manage_schedule'),
(1, 4, 3, 'manage_activities'),
(1, 4, 3, 'view_attendance');

INSERT INTO activity_participation (activity_id, user_id, participation_status)
VALUES
(1, 2, 'active'),
(1, 3, 'active');

INSERT INTO activity_availability (activity_id, user_id, availability_status, note)
VALUES
(1, 2, 'available', 'Μπορώ να έρθω.'),
(1, 3, 'available', 'ΟΚ.');

INSERT INTO club_page_visits (club_id, user_id, visit_code)
VALUES
(1, 2, 'visit-tech-tania'),
(1, 3, 'visit-tech-maria'),
(2, 2, 'visit-music-tania');

INSERT INTO login_activity (user_id, is_active_code)
VALUES
(1, TRUE),
(2, TRUE),
(3, TRUE),
(4, TRUE);

INSERT INTO statistics (stats_userid, statstype, stats, club_id, finalized)
VALUES
(3, 'event statistics', '2 upcoming events, 1 completed event', 1, TRUE),
(3, 'members statistics', '2 approved members in Tech Club', 1, TRUE),
(1, 'app satistics', '4 users, 3 clubs, demo data loaded', NULL, TRUE);
