CluP - τελική φοιτητική έκδοση

Τρέξιμο:

cd backend/v2backend
npm install
npm start

Μετά άνοιξε:
http://localhost:3000

Η εφαρμογή ανοίγει πρώτα στη login φόρμα.

Χρήστες βάσης:
admin@example.com / 123456
manager@example.com / 123456
testuser@example.com / 123456

Το .env είναι ήδη έτοιμο με:
DB_NAME=clup
PORT=3000

Αν η MySQL σου έχει άλλο password, άλλαξε μόνο το DB_PASSWORD στο backend/v2backend/.env.
