import { ClubsAPI, StatisticsAPI } from "../connection_f_b/api.js";

async function loadClubDetails() {
  const params = new URLSearchParams(window.location.search);
  const clubId = params.get("id") || 1;

  try {
    const result = await ClubsAPI.getById(clubId);
    const club = result.data || result;

    setText("clubTitle", club.title || "Σύλλογος");
    setText("clubDescription", club.description || "Δεν υπάρχει περιγραφή.");
    setText("clubManager", club.manager_id ? `Manager ID: ${club.manager_id}` : "");

    document.getElementById("joinBtn")?.addEventListener("click", async () => {
      await ClubsAPI.join(clubId);
      alert("Η αίτηση συμμετοχής στάλθηκε.");
    });

    await StatisticsAPI.recordVisit(clubId, { user_id: 1 }).catch(() => null);
  } catch (error) {
    setText("clubTitle", "Δεν ήταν δυνατή η φόρτωση συλλόγου.");
    setText("clubDescription", "Δοκίμασε να γυρίσεις στη λίστα συλλόγων.");
  }
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

document.addEventListener("DOMContentLoaded", loadClubDetails);
