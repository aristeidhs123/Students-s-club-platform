import {
    AnnouncementsAPI,
    getCurrentUser
} from "../connection_f_b/api.js";

const user = getCurrentUser();
const form = document.getElementById("announcement-form");
const titleInput = document.getElementById("title");
const descriptionInput = document.getElementById("description");
const messageEl = document.getElementById("announcement-message");

if (!user) {
    window.location.href = "login.html";
}

if (user && user.role !== "manager" && user.role !== "admin") {
    window.location.href = "home.html";
}

form.addEventListener("submit", async function (event) {
    event.preventDefault();

    const title = titleInput.value.trim();
    const description = descriptionInput.value.trim();

    if (!title || !description) {
        showMessage("Συμπλήρωσε τίτλο και κείμενο ανακοίνωσης.", false);
        return;
    }

    try {
        await AnnouncementsAPI.createPublic({
            publ_ann_managerid: user.user_id,
            publ_ann_title: title,
            publ_ann_descr: description
        });

        showMessage("Η ανακοίνωση αποθηκεύτηκε επιτυχώς.", true);

        setTimeout(function () {
            window.location.href = "announcements.html";
        }, 700);
    } catch (error) {
        showMessage(error.message || "Δεν ήταν δυνατή η αποθήκευση ανακοίνωσης.", false);
    }
});

function showMessage(text, success) {
    messageEl.textContent = text;
    messageEl.className = success ? "auth-message success" : "auth-message error";
}
