import { ChatbotAPI } from "../connection_f_b/api.js";

async function sendMessage() {
    const input = document.getElementById("chatInput") || document.getElementById("message");
    const chat = document.getElementById("chatWindow") || document.getElementById("chat");
    if (!input || !chat) return;

    const text = input.value.trim();
    if (!text) return;

    chat.innerHTML += `<p><strong>You:</strong> ${text}</p>`;
    input.value = "";

    try {
        const result = await ChatbotAPI.ask({ user_id: 1, problem: text });
        chat.innerHTML += `<p><strong>Bot:</strong> ${result.answer || result.bot_answer || result.message || "Απάντηση καταχωρήθηκε."}</p>`;
    } catch (error) {
        chat.innerHTML += `<p><strong>Bot:</strong> Δεν ήταν δυνατή η επικοινωνία με το backend.</p>`;
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("sendMessageBtn") || document.getElementById("send-btn");
    if (btn) btn.addEventListener("click", sendMessage);

    const input = document.getElementById("chatInput") || document.getElementById("message");
    if (input) input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") sendMessage();
    });

    const contactBtn = document.getElementById("contactAdminBtn");
    const form = document.getElementById("contactForm");
    if (contactBtn && form) {
        contactBtn.addEventListener("click", () => {
            form.style.display = form.style.display === "none" ? "block" : "none";
        });
    }
});
