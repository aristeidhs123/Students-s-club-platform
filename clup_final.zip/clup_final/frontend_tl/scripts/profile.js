import {
    ProfileAPI,
    setCurrentUser,
    getCurrentUser,
    getCurrentUserId
} from "../connection_f_b/api.js";

let loadedProfile = null;

const profileMessage = document.getElementById("profile-message");
const profileClubsList = document.getElementById("profile-clubs-list");

async function loadProfile() {
    const user = getCurrentUser();
    const userId = getCurrentUserId();

    try {
        const result = await ProfileAPI.get(userId);
        const profile = result.data || result.profile || user;
        loadedProfile = profile;

        setText("name", `${profile.name || ""} ${profile.lastname || ""}`.trim() || "Χρήστης");
        setText("email", profile.email || "-");
        setText("role", profile.role || "user");
        setText("interests", profile.user_interests || "Δεν έχουν συμπληρωθεί.");
        setText("bio", profile.user_bio || "Δεν έχει συμπληρωθεί περιγραφή.");
        setText("profile-image-text", profile.profil_img || "Δεν έχει οριστεί.");

        setValue("profile-name-input", profile.name || "");
        setValue("profile-lastname-input", profile.lastname || "");
        setValue("profile-image-input", profile.profil_img || "");
        setValue("profile-bio-input", profile.user_bio || "");
        setValue("profile-interests-input", profile.user_interests || "");

        setCurrentUser({
            ...user,
            ...profile
        });

        await loadUserClubs(userId);
    } catch (error) {
        console.error(error);
        setText("name", "Δεν ήταν δυνατή η φόρτωση προφίλ.");
    }
}

async function loadUserClubs(userId) {
    if (!profileClubsList) return;

    try {
        const result = await ProfileAPI.getUserClubs(userId);
        const clubs = Array.isArray(result?.data) ? result.data : [];

        if (!clubs.length) {
            profileClubsList.innerHTML = "<p>Δεν συμμετέχεις ακόμα σε εγκεκριμένο σύλλογο.</p>";
            return;
        }

        profileClubsList.innerHTML = "";

        clubs.forEach(function (club) {
            const row = document.createElement("div");
            row.className = "mini-list-row";
            row.innerHTML = `
                <span>${escapeHtml(club.title || "Σύλλογος")}</span>
                <button class="secondary-btn" type="button">Αποχώρηση</button>
            `;

            row.querySelector("button").addEventListener("click", async function () {
                await ProfileAPI.leaveClub(userId, club.club_id);
                await loadUserClubs(userId);
            });

            profileClubsList.appendChild(row);
        });
    } catch (error) {
        profileClubsList.innerHTML = "<p>Δεν ήταν δυνατή η φόρτωση συλλόγων.</p>";
    }
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function setValue(id, value) {
    const el = document.getElementById(id);
    if (el) el.value = value;
}

async function saveProfile(event) {
    event.preventDefault();
    const userId = getCurrentUserId();

    const payload = {
        name: document.getElementById("profile-name-input").value.trim(),
        lastname: document.getElementById("profile-lastname-input").value.trim(),
        profil_img: document.getElementById("profile-image-input").value.trim(),
        user_bio: document.getElementById("profile-bio-input").value.trim(),
        user_interests: document.getElementById("profile-interests-input").value.trim()
    };

    try {
        const result = await ProfileAPI.update(userId, payload);
        const updated = result.data || { ...loadedProfile, ...payload };
        setCurrentUser(updated);
        showMessage("Το προφίλ ενημερώθηκε.", true);
        await loadProfile();
    } catch (error) {
        showMessage(error.message || "Σφάλμα αποθήκευσης προφίλ.", false);
    }
}

function showMessage(text, success) {
    if (!profileMessage) return;
    profileMessage.textContent = text;
    profileMessage.className = success ? "auth-message success" : "auth-message error";
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

document.addEventListener("DOMContentLoaded", function () {
    loadProfile();
    const form = document.getElementById("profile-form");
    if (form) form.addEventListener("submit", saveProfile);
});
