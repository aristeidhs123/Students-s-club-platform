import { getCurrentUser, clearCurrentUser } from "../connection_f_b/api.js";

const user = getCurrentUser();
const currentPage = window.location.pathname.split("/").pop() || "login.html";

applyAuthBar();
applyRoleVisibility();
protectPages();

function applyAuthBar() {
  const navbar = document.querySelector(".navbar");
  if (!navbar) return;

  document.querySelectorAll(".login-btn, .auth-nav").forEach(el => el.remove());

  const authBox = document.createElement("div");
  authBox.className = "auth-nav";

  if (user) {
    authBox.innerHTML = `
      <span class="user-chip">${user.name || "User"} · ${roleLabel(user.role)}</span>
      <button class="logout-btn" type="button">Logout</button>
    `;
    authBox.querySelector(".logout-btn").addEventListener("click", () => {
      clearCurrentUser();
      window.location.href = "login.html";
    });
  } else {
    authBox.innerHTML = `<a class="login-btn" href="login.html">Login</a>`;
  }

  navbar.appendChild(authBox);
}

function applyRoleVisibility() {
  const role = user?.role || "guest";

  document.querySelectorAll('a[href="admin.html"], [data-role="admin"]').forEach(el => {
    el.style.display = role === "admin" ? "inline-flex" : "none";
  });

  document.querySelectorAll('[data-role="manager"]').forEach(el => {
    el.style.display = (role === "manager" || role === "admin") ? "" : "none";
  });

  document.querySelectorAll('[data-role="user"]').forEach(el => {
    el.style.display = user ? "" : "none";
  });

  document.querySelectorAll('[data-role="guest"]').forEach(el => {
    el.style.display = user ? "none" : "";
  });
}

function protectPages() {
  const adminOnly = ["admin.html"];
  const managerOrAdmin = ["create_event.html"];
  const loginRequired = ["profile.html", "create_club.html", "review_create.html", "schedule.html"];

  if (adminOnly.includes(currentPage) && user?.role !== "admin") {
    window.location.href = "login.html";
    return;
  }

  if (managerOrAdmin.includes(currentPage) && !(user?.role === "manager" || user?.role === "admin")) {
    window.location.href = "login.html";
    return;
  }

  if (loginRequired.includes(currentPage) && !user) {
    window.location.href = "login.html";
  }
}

function roleLabel(role) {
  if (role === "admin") return "Admin";
  if (role === "manager") return "Manager";
  if (role === "user") return "Student";
  return "Guest";
}
