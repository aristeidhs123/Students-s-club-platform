import { EventsAPI } from "../connection_f_b/api.js";

async function loadEventDetails() {
  const params = new URLSearchParams(window.location.search);
  const eventId = params.get("id") || 1;

  try {
    const result = await EventsAPI.getById(eventId);
    const event = result.data || result;

    setText("eventTitle", event.ev_title || "Εκδήλωση");
    setText("eventDescription", event.ev_description || "Δεν υπάρχει περιγραφή.");
    setText("eventLocation", event.ev_location || "-");
    setText("eventSeats", event.ev_seats ?? "-");
    setText("eventStart", event.ev_starttime || "-");
    setText("eventEnd", event.ev_endtime || "-");

    document.getElementById("participateBtn")?.addEventListener("click", async () => {
      await EventsAPI.participate(eventId);
      alert("Η συμμετοχή καταχωρήθηκε.");
    });

    document.getElementById("rateEventBtn")?.addEventListener("click", () => {
      window.location.href = `review_create.html?eventId=${eventId}`;
    });
  } catch (error) {
    setText("eventTitle", "Δεν ήταν δυνατή η φόρτωση εκδήλωσης.");
  }
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

document.addEventListener("DOMContentLoaded", loadEventDetails);
