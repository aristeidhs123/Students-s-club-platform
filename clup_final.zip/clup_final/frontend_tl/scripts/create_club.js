import { ClubsAPI, getCurrentUserId } from "../connection_f_b/api.js";

document.addEventListener("DOMContentLoaded", () => {
    const inputs = document.querySelectorAll("input, textarea");
    const button = document.querySelector("button.primary-btn");
    if (!button) return;

    button.addEventListener("click", async () => {
        const title = inputs[0]?.value?.trim();
        const description = inputs[1]?.value?.trim();
        if (!title || !description) return alert("Συμπλήρωσε όνομα και περιγραφή συλλόγου.");

        try {
            await ClubsAPI.create({ title, description, managerid: getCurrentUserId() });
            alert("Η αίτηση δημιουργίας συλλόγου στάλθηκε στο backend.");
            window.location.href = "clubs.html";
        } catch (error) {
            alert("Σφάλμα αποστολής αίτησης συλλόγου.");
        }
    });
});
