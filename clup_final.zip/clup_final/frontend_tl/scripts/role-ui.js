import {
    getCurrentUser,
    clearCurrentUser
} from "../connection_f_b/api.js";

const user = getCurrentUser();
const currentPage = location.pathname.split("/").pop() || "login.html";

const publicPages = ["login.html", "index.html"];

if (!user && !publicPages.includes(currentPage)) {
    window.location.href = "login.html";
}

if (user) {
    setupNavbar(user);
    protectPage(user);
    showRoleMessage(user);
}

function setupNavbar(user) {
    const navbar = document.querySelector(".navbar");
    if (!navbar) return;

    navbar.innerHTML = "";

    const logo = document.createElement("a");
    logo.className = "logo";
    logo.href = "home.html";
    logo.innerHTML = "Cl<span>UP</span>";

    const navLinks = document.createElement("nav");
    navLinks.className = "nav-links";

    const role = user.role || "user";
    const links = getLinksForRole(role);

    links.forEach(function (link) {
        const a = document.createElement("a");
        a.href = link.href;
        a.textContent = link.text;

        if (currentPage === link.href) {
            a.classList.add("active");
        }

        navLinks.appendChild(a);
    });

    const actions = document.createElement("div");
    actions.className = "navbar-actions";

    const userBadge = document.createElement("span");
    userBadge.className = "user-badge";
    userBadge.textContent = getUserLabel(user);

    const logoutBtn = document.createElement("button");
    logoutBtn.className = "logout-btn";
    logoutBtn.type = "button";
    logoutBtn.textContent = "Logout";

    logoutBtn.addEventListener("click", function () {
        clearCurrentUser();
        window.location.href = "login.html";
    });

    actions.appendChild(userBadge);
    actions.appendChild(logoutBtn);

    navbar.appendChild(logo);
    navbar.appendChild(navLinks);
    navbar.appendChild(actions);
}

function getLinksForRole(role) {
    const commonLinks = [
        { href: "home.html", text: "Home" },
        { href: "clubs.html", text: "Clubs" },
        { href: "events.html", text: "Events" },
        { href: "announcements.html", text: "Announcements" },
        { href: "reviews.html", text: "Reviews" },
        { href: "profile.html", text: "Profile" },
        { href: "chatbox.html", text: "Help" }
    ];

    if (role === "admin") {
        return [
            ...commonLinks,
            { href: "statistics.html", text: "App Statistics" },
            { href: "admin.html", text: "Admin" }
        ];
    }

    if (role === "manager") {
        return [
            ...commonLinks,
            { href: "announcement_create.html", text: "Create Announcement" },
            { href: "create_event.html", text: "Create Event" },
            { href: "schedule.html", text: "Schedule" },
            { href: "statistics.html", text: "Club Statistics" },
            { href: "admin.html", text: "Club Panel" }
        ];
    }

    return commonLinks;
}

function getUserLabel(user) {
    const name = user.name || user.email || "User";
    const role = user.role || "user";

    if (role === "admin") return name + " · Admin";
    if (role === "manager") return name + " · Manager";

    return name + " · Student";
}

function protectPage(user) {
    const role = user.role || "user";

    const managerOrAdminPages = [
        "admin.html",
        "create_event.html",
        "announcement_create.html",
        "schedule.html",
        "statistics.html"
    ];

    if (managerOrAdminPages.includes(currentPage) && role !== "manager" && role !== "admin") {
        window.location.href = "home.html";
    }
}

function showRoleMessage(user) {
    const messageBox = document.querySelector("[data-role-message]");
    if (!messageBox) return;

    const role = user.role || "user";

    if (role === "admin") {
        messageBox.textContent = "Συνδέθηκες ως admin. Βλέπεις λειτουργίες εποπτείας και στατιστικά εφαρμογής.";
    } else if (role === "manager") {
        messageBox.textContent = "Συνδέθηκες ως διαχειριστής συλλόγου. Βλέπεις λειτουργίες ομάδας, πρόγραμμα και στατιστικά συλλόγου.";
    } else {
        messageBox.textContent = "Συνδέθηκες ως φοιτητής. Μπορείς να δεις συλλόγους, εκδηλώσεις, ανακοινώσεις και αξιολογήσεις.";
    }
}
