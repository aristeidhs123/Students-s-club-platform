import {
    AuthAPI,
    setCurrentUser,
    getCurrentUser
} from "../connection_f_b/api.js";

const form = document.getElementById("login-form");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const submitBtn = document.getElementById("submit-auth");
const messageEl = document.getElementById("auth-message");
const togglePassword = document.getElementById("toggle-password");
const demoButtons = document.querySelectorAll(".demo-account");

const existingUser = getCurrentUser();

if (existingUser) {
    showMessage(
        "Είσαι ήδη συνδεδεμένος/η ως " + (existingUser.name || existingUser.email) + ".",
        true
    );
}

demoButtons.forEach(function (button) {
    button.addEventListener("click", function () {
        emailInput.value = button.dataset.email;
        passwordInput.value = button.dataset.password;
        showMessage("Συμπληρώθηκε δοκιμαστικός λογαριασμός.", true);
    });
});

togglePassword.addEventListener("click", function () {
    const showPassword = passwordInput.type === "password";

    passwordInput.type = showPassword ? "text" : "password";
    togglePassword.textContent = showPassword ? "Hide" : "Show";
});

form.addEventListener("submit", async function (event) {
    event.preventDefault();

    const email = emailInput.value.trim();
    const password = passwordInput.value;

    if (!email || !password) {
        showMessage("Συμπλήρωσε email και password.", false);
        return;
    }

    try {
        submitBtn.disabled = true;
        submitBtn.textContent = "Σύνδεση...";

        const result = await AuthAPI.login({
            email: email,
            password: password
        });

        const user = result.data || result.user || result;

        if (!user || !user.email) {
            throw new Error("Το backend δεν επέστρεψε σωστό χρήστη.");
        }

        setCurrentUser(user);

        showMessage("Επιτυχής σύνδεση. Μεταφέρεσαι στην αρχική...", true);

        setTimeout(function () {
            window.location.href = "home.html";
        }, 600);

    } catch (error) {
        showMessage(error.message || "Δεν ήταν δυνατή η σύνδεση.", false);
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = "Login";
    }
});

function showMessage(text, success) {
    messageEl.textContent = text;
    messageEl.className = success ? "auth-message success" : "auth-message error";
}