import {
    ScheduleAPI,
    getCurrentUser
} from "../connection_f_b/api.js";

const user = getCurrentUser();

const clubIdInput = document.getElementById("club-id");
const loadBtn = document.getElementById("load-schedule");
const messageEl = document.getElementById("schedule-message");
const scheduleTitle = document.getElementById("schedule-title");
const scheduleList = document.getElementById("schedule-list");
const activityForm = document.getElementById("activity-form");
const scheduleIdInput = document.getElementById("schedule-id");

if (!user) {
    window.location.href = "login.html";
}

if (user && user.role !== "manager" && user.role !== "admin") {
    window.location.href = "home.html";
}

loadBtn.addEventListener("click", loadSchedule);
activityForm.addEventListener("submit", addActivity);

document.addEventListener("DOMContentLoaded", loadSchedule);

async function loadSchedule() {
    const clubId = clubIdInput.value || 1;

    try {
        showMessage("Φόρτωση χρονοδιαγράμματος...", true);
        scheduleList.innerHTML = "";

        let result = await ScheduleAPI.getByClub(clubId);
        let schedules = normalize(result);

        if (!schedules.length) {
            const today = new Date().toISOString().slice(0, 10);
            const nextMonth = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

            await ScheduleAPI.createSchedule({
                club_id: Number(clubId),
                created_by: user.user_id,
                title: "Βασικό χρονοδιάγραμμα συλλόγου",
                description: "Αυτόματο αρχικό χρονοδιάγραμμα για δοκιμές.",
                start_date: today,
                end_date: nextMonth
            });

            result = await ScheduleAPI.getByClub(clubId);
            schedules = normalize(result);
        }

        if (!schedules.length) {
            scheduleTitle.textContent = "Δεν υπάρχει χρονοδιάγραμμα";
            showMessage("Δεν βρέθηκε χρονοδιάγραμμα για αυτό το club.", false);
            return;
        }

        const schedule = schedules[0];
        scheduleIdInput.value = schedule.schedule_id;
        scheduleTitle.textContent = schedule.title || "Schedule";

        await loadActivities(schedule.schedule_id);
        showMessage("Το χρονοδιάγραμμα φορτώθηκε.", true);
    } catch (error) {
        showMessage(error.message || "Δεν ήταν δυνατή η φόρτωση χρονοδιαγράμματος.", false);
    }
}

async function loadActivities(scheduleId) {
    const result = await ScheduleAPI.getActivities(scheduleId);
    const activities = normalize(result);

    if (!activities.length) {
        scheduleList.innerHTML = `
            <article class="card">
                <div class="card-content">
                    <h3>Δεν υπάρχουν δραστηριότητες</h3>
                    <p>Πρόσθεσε την πρώτη δραστηριότητα από τη φόρμα.</p>
                </div>
            </article>
        `;
        return;
    }

    scheduleList.innerHTML = "";

    activities.forEach(function (activity) {
        const card = document.createElement("article");
        card.className = "card card-blue";
        card.innerHTML = `
            <div class="card-content">
                <h3>${escapeHtml(activity.title)}</h3>
                <p>${escapeHtml(activity.description || "Δεν υπάρχει περιγραφή.")}</p>
                <p><strong>Date:</strong> ${escapeHtml(String(activity.activity_date).slice(0, 10))}</p>
                <p><strong>Time:</strong> ${escapeHtml(activity.start_time || "-")} - ${escapeHtml(activity.end_time || "-")}</p>
                <p><strong>Location:</strong> ${escapeHtml(activity.location || "-")}</p>
            </div>
        `;
        scheduleList.appendChild(card);
    });
}

async function addActivity(event) {
    event.preventDefault();

    const scheduleId = scheduleIdInput.value;

    if (!scheduleId) {
        showMessage("Φόρτωσε πρώτα χρονοδιάγραμμα.", false);
        return;
    }

    const payload = {
        schedule_id: Number(scheduleId),
        created_by: user.user_id,
        title: document.getElementById("activity-title").value.trim(),
        description: document.getElementById("activity-description").value.trim(),
        activity_date: document.getElementById("activity-date").value,
        start_time: document.getElementById("start-time").value || null,
        end_time: document.getElementById("end-time").value || null,
        location: document.getElementById("activity-location").value.trim() || null
    };

    try {
        await ScheduleAPI.addActivity(payload);
        showMessage("Η δραστηριότητα αποθηκεύτηκε.", true);
        activityForm.reset();
        await loadActivities(scheduleId);
    } catch (error) {
        showMessage(error.message || "Δεν ήταν δυνατή η αποθήκευση δραστηριότητας.", false);
    }
}

function normalize(result) {
    if (Array.isArray(result)) return result;
    if (Array.isArray(result?.data)) return result.data;
    return [];
}

function showMessage(text, success) {
    messageEl.textContent = text;
    messageEl.className = success ? "auth-message success" : "auth-message error";
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
