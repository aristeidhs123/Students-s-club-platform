import { ClubsAPI, EventsAPI, AnnouncementsAPI, ProfileAPI, getCurrentUser } from "../connection_f_b/api.js";

let allItems = [];

document.addEventListener("DOMContentLoaded", async () => {
  const [clubsResult, eventsResult, announcementsResult] = await Promise.allSettled([
    loadHomeClubs(),
    loadHomeEvents(),
    loadHomeAnnouncements()
  ]);

  await loadHomeProfile();
  setupSearch();
});

function listFrom(result) {
  if (Array.isArray(result)) return result;
  if (Array.isArray(result?.data)) return result.data;
  if (Array.isArray(result?.reviews)) return result.reviews;
  return [];
}

function setEmpty(id, text) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = `<p>${text}</p>`;
}

async function loadHomeClubs() {
  try {
    const result = await ClubsAPI.getAll();
    const clubs = listFrom(result).filter(c => !c.status || c.status === "approved");
    document.getElementById("clubCount").textContent = clubs.length;
    allItems.push(...clubs.map(c => ({ type: "club", title: c.title, description: c.description })));
    renderClubs(clubs.slice(0, 3));
  } catch (error) {
    setEmpty("clubsGrid", "Δεν ήταν δυνατή η φόρτωση συλλόγων.");
  }
}

async function loadHomeEvents() {
  try {
    const result = await EventsAPI.getAll();
    const events = listFrom(result);
    document.getElementById("eventCount").textContent = events.length;
    allItems.push(...events.map(e => ({ type: "event", title: e.ev_title, description: e.ev_description })));
    renderEvents(events.slice(0, 2));
  } catch (error) {
    setEmpty("eventsGrid", "Δεν ήταν δυνατή η φόρτωση εκδηλώσεων.");
  }
}

async function loadHomeAnnouncements() {
  try {
    const result = await AnnouncementsAPI.getAll();
    const announcements = listFrom(result);
    document.getElementById("annCount").textContent = announcements.length;
    allItems.push(...announcements.map(a => ({ type: "announcement", title: a.publ_ann_title || a.ann_title, description: a.publ_ann_descr || a.ann_descr })));
    renderAnnouncements(announcements.slice(0, 2));
  } catch (error) {
    setEmpty("announcementsGrid", "Δεν ήταν δυνατή η φόρτωση ανακοινώσεων.");
  }
}

async function loadHomeProfile() {
  const user = getCurrentUser();
  if (!user) return;

  try {
    const result = await ProfileAPI.get(user.user_id);
    const p = result.data || result.profile || user;
    setText("profileName", `${p.name || ""} ${p.lastname || ""}`.trim() || "Χρήστης");
    setText("profileRole", p.role || "user");
    setText("profileInterests", p.user_interests || "Δεν έχουν συμπληρωθεί.");
    setText("profileBio", p.user_bio || "Δεν έχει συμπληρωθεί περιγραφή.");
  } catch (error) {
    setText("profileName", user.name || user.email || "Χρήστης");
  }
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function renderClubs(clubs) {
  const grid = document.getElementById("clubsGrid");
  if (!grid) return;
  grid.innerHTML = "";
  if (!clubs.length) return setEmpty("clubsGrid", "Δεν υπάρχουν εγκεκριμένοι σύλλογοι στη βάση.");

  clubs.forEach(c => {
    const card = document.createElement("div");
    card.className = "card card-blue";
    card.innerHTML = `
      <div class="card-top gradient-1"></div>
      <div class="card-content">
        <h3>${c.title}</h3>
        <p>${c.description || ""}</p>
        <button class="card-btn" onclick="window.location.href='club_details.html?id=${c.club_id}'">View Club</button>
      </div>`;
    grid.appendChild(card);
  });
}

function renderEvents(events) {
  const grid = document.getElementById("eventsGrid");
  if (!grid) return;
  grid.innerHTML = "";
  if (!events.length) return setEmpty("eventsGrid", "Δεν υπάρχουν εκδηλώσεις στη βάση.");

  events.forEach(e => {
    const card = document.createElement("div");
    card.className = "card card-purple";
    card.innerHTML = `
      <div class="card-top gradient-2"></div>
      <div class="card-content">
        <h3>${e.ev_title}</h3>
        <p>${e.ev_description || ""}</p>
        <p><strong>Location:</strong> ${e.ev_location || "-"}</p>
        <p><strong>Seats:</strong> ${e.ev_seats ?? "-"}</p>
        <button class="card-btn" onclick="window.location.href='event_details.html?id=${e.event_id}'">View Event</button>
      </div>`;
    grid.appendChild(card);
  });
}

function renderAnnouncements(list) {
  const grid = document.getElementById("announcementsGrid");
  if (!grid) return;
  grid.innerHTML = "";
  if (!list.length) return setEmpty("announcementsGrid", "Δεν υπάρχουν ανακοινώσεις στη βάση.");

  list.forEach(a => {
    const title = a.publ_ann_title || a.ann_title || "Ανακοίνωση";
    const descr = a.publ_ann_descr || a.ann_descr || "";
    const card = document.createElement("div");
    card.className = "card card-cyan";
    card.innerHTML = `
      <div class="card-top gradient-3"></div>
      <div class="card-content">
        <h3>${title}</h3>
        <p>${descr}</p>
      </div>`;
    grid.appendChild(card);
  });
}

function setupSearch() {
  const input = document.getElementById("homeSearch");
  const btn = document.getElementById("homeSearchBtn");
  if (!input || !btn) return;

  btn.addEventListener("click", () => {
    const q = input.value.trim().toLowerCase();
    if (!q) return;
    const match = allItems.find(item => `${item.title || ""} ${item.description || ""}`.toLowerCase().includes(q));
    if (!match) return alert("Δεν βρέθηκε κάτι σχετικό στην αρχική λίστα.");
    alert(`Βρέθηκε ${match.type}: ${match.title}`);
  });
}
