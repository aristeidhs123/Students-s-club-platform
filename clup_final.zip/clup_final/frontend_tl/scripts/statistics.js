import {
    getCurrentUser,
    StatisticsAPI
} from "../connection_f_b/api.js";

const user = getCurrentUser();
const title = document.getElementById("statistics-title");
const container = document.getElementById("statistics-content");

if (!user) {
    window.location.href = "login.html";
}

if (user && user.role === "user") {
    window.location.href = "home.html";
}

renderStatisticsPage();

function renderStatisticsPage() {
    if (!container || !user) return;

    if (user.role === "admin") {
        renderAdminStatistics();
        return;
    }

    if (user.role === "manager") {
        renderClubStatistics();
        return;
    }

    container.innerHTML = `<article class="card"><div class="card-content"><h3>Δεν έχεις πρόσβαση</h3></div></article>`;
}

function renderAdminStatistics() {
    title.textContent = "Στατιστικά Εφαρμογής";

    container.innerHTML = `
        <article class="card statistics-card">
            <div class="card-content">
                <h3>Στατιστικά Εφαρμογής</h3>
                <p>Ο admin βλέπει συνολικά στοιχεία για την πλατφόρμα.</p>

                <div class="stat-actions">
                    <button class="primary-btn" id="load-app-options">Διαθέσιμα στατιστικά</button>
                    <button class="secondary-btn" id="load-chatbot-usage">Χρήση chatbot</button>
                    <button class="secondary-btn" id="load-chatbot-efficiency">Αποδοτικότητα chatbot</button>
                    <button class="secondary-btn" id="load-app-usage">Χρήση εφαρμογής</button>
                </div>

                <div id="stats-output" class="stats-cards-output">
                    <p class="muted-text">Επίλεξε στατιστικό για προβολή.</p>
                </div>
            </div>
        </article>
    `;

    const output = document.getElementById("stats-output");

    document.getElementById("load-app-options").addEventListener("click", function () {
        showResult(output, StatisticsAPI.appOptions);
    });

    document.getElementById("load-chatbot-usage").addEventListener("click", function () {
        showResult(output, StatisticsAPI.chatbotUsage);
    });

    document.getElementById("load-chatbot-efficiency").addEventListener("click", function () {
        showResult(output, StatisticsAPI.chatbotEfficiency);
    });

    document.getElementById("load-app-usage").addEventListener("click", function () {
        showResult(output, StatisticsAPI.appUsage);
    });
}

function renderClubStatistics() {
    title.textContent = "Στατιστικά Ομάδας";

    container.innerHTML = `
        <article class="card statistics-card">
            <div class="card-content">
                <h3>Στατιστικά Ομάδας</h3>
                <p>Ο διαχειριστής συλλόγου βλέπει στοιχεία για την ομάδα του.</p>

                <div class="form-group">
                    <label for="club-id">Club ID</label>
                    <input id="club-id" type="number" value="1" min="1">
                </div>

                <div class="stat-actions">
                    <button class="primary-btn" id="load-club-options">Διαθέσιμα στατιστικά</button>
                    <button class="secondary-btn" id="load-club-events">Στατιστικά εκδηλώσεων</button>
                    <button class="secondary-btn" id="load-member-participation">Συμμετοχή μελών</button>
                    <button class="secondary-btn" id="load-club-visits">Επισκεψιμότητα</button>
                </div>

                <div id="stats-output" class="stats-cards-output">
                    <p class="muted-text">Επίλεξε στατιστικό για προβολή.</p>
                </div>
            </div>
        </article>
    `;

    const output = document.getElementById("stats-output");
    const clubIdInput = document.getElementById("club-id");

    document.getElementById("load-club-options").addEventListener("click", function () {
        showResult(output, StatisticsAPI.clubOptions);
    });

    document.getElementById("load-club-events").addEventListener("click", function () {
        showResult(output, function () {
            return StatisticsAPI.clubEvents(clubIdInput.value || 1);
        });
    });

    document.getElementById("load-member-participation").addEventListener("click", function () {
        showResult(output, function () {
            return StatisticsAPI.memberParticipation(clubIdInput.value || 1);
        });
    });

    document.getElementById("load-club-visits").addEventListener("click", function () {
        showResult(output, function () {
            return StatisticsAPI.clubVisits(clubIdInput.value || 1);
        });
    });
}

async function showResult(output, requestFunction) {
    try {
        output.innerHTML = `<p class="muted-text">Φόρτωση...</p>`;
        const result = await requestFunction();
        renderPrettyStats(output, result);
    } catch (error) {
        output.innerHTML = `
            <div class="mini-stat-card error-card">
                <h4>Δεν ήταν δυνατή η φόρτωση</h4>
                <p>${escapeHtml(error.message || "Σφάλμα στα στατιστικά.")}</p>
            </div>
        `;
    }
}

function renderPrettyStats(output, result) {
    const items = result?.options || result?.data || result?.statistics || result?.stats || [];

    if (Array.isArray(items) && items.length) {
        output.innerHTML = "";
        items.forEach(function (item) {
            output.appendChild(makeStatCard(item.title || item.type || item.name || "Στατιστικό", item.value || item.count || item.total || item.description || item.type || "-"));
        });
        return;
    }

    if (typeof items === "object" && items !== null && !Array.isArray(items)) {
        output.innerHTML = "";
        Object.entries(items).forEach(function ([key, value]) {
            output.appendChild(makeStatCard(key, formatValue(value)));
        });
        return;
    }

    if (typeof result === "object" && result !== null) {
        const entries = Object.entries(result).filter(function ([key]) {
            return key !== "success" && key !== "message";
        });

        if (entries.length) {
            output.innerHTML = "";
            entries.forEach(function ([key, value]) {
                output.appendChild(makeStatCard(key, formatValue(value)));
            });
            return;
        }
    }

    output.innerHTML = `<div class="mini-stat-card"><h4>Δεν υπάρχουν δεδομένα</h4><p>Το backend απάντησε χωρίς διαθέσιμα στατιστικά.</p></div>`;
}

function makeStatCard(title, value) {
    const card = document.createElement("div");
    card.className = "mini-stat-card";
    card.innerHTML = `<h4>${escapeHtml(String(title))}</h4><p>${escapeHtml(String(value))}</p>`;
    return card;
}

function formatValue(value) {
    if (typeof value === "object") return JSON.stringify(value);
    return String(value);
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
