import { EventsAPI } from "../connection_f_b/api.js";

document.addEventListener("DOMContentLoaded", () => {
    const inputs = document.querySelectorAll("input, textarea");
    const button = document.querySelector("button.primary-btn");
    if (!button) return;

    button.addEventListener("click", async () => {
        const title = inputs[0]?.value?.trim();
        const description = inputs[1]?.value?.trim();
        const location = inputs[2]?.value?.trim();
        const seats = inputs[3]?.value || 0;
        const starttime = inputs[4]?.value;

        if (!title || !description || !location || !starttime) {
            return alert("Συμπλήρωσε τίτλο, περιγραφή, τοποθεσία και ημερομηνία.");
        }

        const start = starttime.replace("T", " ") + ":00";
        const endDate = new Date(starttime);
        endDate.setHours(endDate.getHours() + 2);
        const end = endDate.toISOString().slice(0, 19).replace("T", " ");

        try {
            await EventsAPI.create({
                evclubid: 1,
                title,
                description,
                role: "public",
                seats,
                location,
                gplatos: 38.246242,
                gmikos: 21.735084,
                starttime: start,
                endtime: end
            });
            alert("Η εκδήλωση στάλθηκε στο backend.");
            window.location.href = "events.html";
        } catch (error) {
            alert("Σφάλμα δημιουργίας εκδήλωσης.");
        }
    });
});
