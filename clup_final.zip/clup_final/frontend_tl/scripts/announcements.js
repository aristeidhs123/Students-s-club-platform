import {
    AnnouncementsAPI,
    getCurrentUser
} from "../connection_f_b/api.js";

const user = getCurrentUser();
const announcementsList = document.getElementById("announcements-list");
const createAnnouncementLink = document.getElementById("create-announcement-link");

initAnnouncementsPage();

async function initAnnouncementsPage() {
    setupCreateButton();
    await loadAnnouncements();
}

function setupCreateButton() {
    if (!createAnnouncementLink) return;

    if (!user || (user.role !== "manager" && user.role !== "admin")) {
        createAnnouncementLink.style.display = "none";
    }
}

async function loadAnnouncements() {
    if (!announcementsList) return;

    announcementsList.innerHTML = `
        <article class="card">
            <div class="card-content">
                <p>Φόρτωση ανακοινώσεων...</p>
            </div>
        </article>
    `;

    try {
        const result = await AnnouncementsAPI.getAll();
        const announcements = normalizeResponse(result);

        if (!announcements.length) {
            announcementsList.innerHTML = `
                <article class="card">
                    <div class="card-content">
                        <h3>Δεν υπάρχουν ανακοινώσεις</h3>
                        <p>Δεν έχει δημοσιευτεί ακόμα κάποια ανακοίνωση.</p>
                    </div>
                </article>
            `;
            return;
        }

        announcementsList.innerHTML = "";

        announcements.forEach(function (announcement, index) {
            announcementsList.appendChild(createAnnouncementCard(announcement, index));
        });
    } catch (error) {
        announcementsList.innerHTML = `
            <article class="card">
                <div class="card-content">
                    <h3>Δεν ήταν δυνατή η φόρτωση</h3>
                    <p>${escapeHtml(error.message || "Κάτι πήγε στραβά με τις ανακοινώσεις.")}</p>
                </div>
            </article>
        `;
    }
}

function normalizeResponse(result) {
    if (Array.isArray(result)) return result;
    if (Array.isArray(result?.data)) return result.data;
    if (Array.isArray(result?.announcements)) return result.announcements;
    return [];
}

function createAnnouncementCard(announcement, index) {
    const card = document.createElement("article");
    const colorClass = index % 2 === 0 ? "card-cyan" : "card-purple";
    const gradientClass = index % 2 === 0 ? "gradient-3" : "gradient-2";

    card.className = "card " + colorClass;

    const title = announcement.ann_title || announcement.publ_ann_title || announcement.title || "Ανακοίνωση";
    const description = announcement.ann_descr || announcement.publ_ann_descr || announcement.description || "Δεν υπάρχει περιγραφή.";
    const club = announcement.club_title || announcement.ann_clubid || "-";
    const date = announcement.ann_date || announcement.publ_ann_date || "-";

    card.innerHTML = `
        <div class="card-top ${gradientClass}"></div>
        <div class="card-content">
            <h3>${escapeHtml(title)}</h3>
            <p>${escapeHtml(description)}</p>
            <p class="muted-text"><strong>Club:</strong> ${escapeHtml(String(club))}</p>
            <p class="muted-text"><strong>Date:</strong> ${escapeHtml(formatDate(date))}</p>
            <button class="card-btn" type="button">View Announcement</button>
        </div>
    `;

    card.querySelector(".card-btn").addEventListener("click", function () {
        localStorage.setItem("selected_announcement", JSON.stringify(announcement));
        window.location.href = "announcement_details.html";
    });

    return card;
}

function formatDate(value) {
    if (!value || value === "-") return "-";
    return String(value).slice(0, 10);
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
